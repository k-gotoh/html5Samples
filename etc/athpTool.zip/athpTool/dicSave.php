<?php

function msg( $msg ) {

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
</head>
<body>
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

}

function insertRec($connect, $eid, $dic, $status) {

  $dicList = explode( ',', $dic );

  if ( count( $dicList ) == 0 || $dicList[0] == "" ) {
    return;
  }

  for ( $i = 0; $i < count( $dicList ); $i++ ) {

    $name = explode(':', $dicList[$i]);

    $sql  = "insert into m_dic value(";
    $sql .= "'"  . $eid . "'";
    $sql .= ",'"  . $status. "'";
    $sql .= ","  . $i;
    $sql .= ",'" . $name[0] . "'";
    $sql .= ",'" . $name[1] . "'";
    $sql .= ")";

    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
      print ( $sql );
      return;
    }
  }
}


include '../connect.php';
$STATUS_USE_DIC = "0";
$STATUS_VISIBLE_DIC = "1";
$STATUS_INVISIBLE_DIC = "2";

$db = "hptool";

$eid = $_POST['eid'];
$useDic = $_POST['useDic'];
$visibleDic = $_POST['visibleDic'];
$invisibleDic = $_POST['invisibleDic'];



// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  mysql_query( "begin", $connect );


  $sql = "delete from m_dic where eid = '" . $eid . "'";
  mysql_query( $sql, $connect ) or die("deleteに失敗しました。");


  insertRec( $connect, $eid , $useDic, $STATUS_USE_DIC);
  insertRec( $connect, $eid , $visibleDic, $STATUS_VISIBLE_DIC);
  insertRec( $connect, $eid , $invisibleDic, $STATUS_INVISIBLE_DIC);


  mysql_query( "commit", $connect );
  
  msg( "更新しました" );


  // MySQLへの接続を閉じる
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>