<?php


include '../connect.php';

$db = "hptool";

$useCond = isset($_POST[ 'useCond' ])? " or " : " and ";

$whereArray  = array();
$useArray  = array();
$statusArray  = array();




if  ( $_POST[ 'userName' ]  != "" ) {
  array_push( $whereArray, " client_name like '" . $_POST[ 'userName' ] . "*' " );
}

if  ( $_POST[ 'settingID' ]  != "" ) {
  array_push( $whereArray, " setting_id = '" . $_POST[ 'settingID' ] . "' " );
}

//
$planDateFrom = $_POST[ 'planDateFrom' ];
if  ( $planDateFrom == "" ) {
  $planDateFrom = "";
}

$planDateTo = $_POST[ 'planDateTo' ];
if  ( $planDateTo == "" ) {
  $planDateTo = "9999-99-99";
}
array_push( $whereArray, " plan_date between '" . $planDateFrom . "' and '" . $planDateTo . "'" );

//
if  ( isset($_POST[ 'useCDN' ]) ) {
   array_push( $useArray, " use_cdn = '1' " );
}

if  ( isset($_POST[ 'useMobile' ]) ) {
   array_push( $useArray, " use_mobile = '1' " );
}

if  ( isset($_POST[ 'usePDF' ]) ) {
   array_push( $useArray, " use_pdf = '1' " );
}
if  ( count( $useArray ) > 0 ) {
  array_push( $whereArray, " (" . implode( $useCond, $useArray ) . ") " );
}

//
//
if  ( isset($_POST[ 'status01' ]) ) {
   array_push( $statusArray, " status = '1' " );
}
if  ( isset($_POST[ 'status02' ]) ) {
   array_push( $statusArray, " status = '2' " );
}
if  ( isset($_POST[ 'status03' ]) ) {
   array_push( $statusArray, " status = '3' " );
}
if  ( isset($_POST[ 'status09' ]) ) {
   array_push( $statusArray, " status = '9' " );
}
if  ( count( $statusArray ) > 0 ) {
  array_push( $whereArray, " (" . implode( " or ", $statusArray ) . ") " );
}



$where = " where " . implode(" and ", $whereArray);



// MySQLへ接続する
$connect = connect();

  // データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

$engineNameList = array();
$sql = "select eid, name from m_engine";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
    $engineNameList[ $row[ 'eid' ] ] = $row[ 'name' ];
}


$data = "";
$sql = "select * from m_user " . $where;
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
    
    $rowUseCDN = $row[ 'use_cdn' ] == "1" ?  "○" : "×";
    $rowUseMobile = $row[ 'use_mobile' ] == "1" ?  "○" : "×";
    $rowUsePDF = $row[ 'use_pdf' ] == "1" ?  "○" : "×";

    $fileCreate = '<td name=""><input type="checkbox" name="createFile" onclick="setHeaderButton( \'createFile\' )"></td>';
    $requestCheck = '<td name=""><input type="checkbox" name="requestCheck" onclick="setHeaderButton( \'requestCheck\' )"></td>';
    $checkCompleted = '<td name=""><input type="checkbox" name="checkCompleted" onclick="setHeaderButton( \'checkCompleted\' )"></td>';
    $released = '<td name=""><input type="checkbox" name="released" onclick="setHeaderButton( \'released\' )"></td>';
    $deleteUser = '<td name=""><input type="checkbox" name="delete" onclick="setHeaderButton( \'delete\' )"></td>';

    $empty = "<td></td>";

    $rowStatus = "";
    $changeStatusCbx = "<td></td><td></td><td></td>";
    switch ( (int) $row[ 'status' ] )
    {
      case 1:
        $rowStatus =  "登録中";
        $changeStatusCbx  = $fileCreate . $requestCheck . $empty          . $empty    . $deleteUser;
        break;
      case 2:
        $rowStatus =  "開発チェック中";
        $changeStatusCbx  = $fileCreate . $requestCheck . $checkCompleted . $empty    . $deleteUser;
        break;

      case 3:
        $rowStatus =  "チェック完";
        $changeStatusCbx  = $fileCreate . $requestCheck . $empty          . $released . $deleteUser;
        break;

      case 4:
        $rowStatus =  "リリース済";
        $changeStatusCbx  = $fileCreate . $requestCheck . $empty          . $empty    . $deleteUser;
        break;

      case 9:
        $rowStatus =  "キャンセル";
        $changeStatusCbx  = $empty . $empty . $empty          . $empty    . $empty;
        break;
    }

    $eids = "";
    $eidArray = array();
    $sql = "select eid from t_use_engine where user_id = '" . $row[ 'user_id' ] . "'";
    $resultEid = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
    while ($rowEid = mysql_fetch_assoc($resultEid)) {
        array_push( $eidArray, $engineNameList[ $rowEid[ 'eid' ] ] );
    }
    if ( count( $eidArray ) > 0 ) {
        $eids = implode( ",", $eidArray );
    }



    $rowID = $row[ 'user_id' ];
    $rowsettingID = $row[ 'setting_id' ];
    $rowClientName = $row[ 'client_name' ];
    $rowPlanDate = $row[ 'plan_date' ];
    $rowCompletedDate = $row[ 'complete_date' ];
    $data .= <<< DATA_EOF
    <tr  id="$rowID" >
        <td name="userCode" onClick="showDetails(this)">$rowsettingID</td>
        <td name="userName" onClick="showDetails(this)">$rowClientName</td>     
        <td name="engine" onClick="showDetails(this)">$eids</td>     
        <td name="cdn" onClick="showDetails(this)">$rowUseCDN</td>
        <td name="mobile" onClick="showDetails(this)">$rowUseMobile</td>
        <td name="pdf" onClick="showDetails(this)">$rowUsePDF</td>
        <td name="status" onClick="showDetails(this)">$rowStatus</td>
        <td name="planDate" onClick="showDetails(this)">$rowPlanDate</td>
        <td name="endDate" onClick="showDetails(this)">$rowCompletedDate</td>
        $changeStatusCbx
    </tr> 

DATA_EOF;

}





$html = <<< EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />


<link rel="stylesheet" href="./css/roundedTextBox.css" type="text/css" />
<link rel="stylesheet" href="./css/checkBoxGroup.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="./css/style4_little.css" />
<link rel="stylesheet" href="./css/buttons.css" />

<style type="text/css">
table {
    *border-collapse: collapse; /* IE7 and lower */
    border-spacing: 0;
    width: 100%;    
}

.bordered {
    border: solid #ccc 1px;
    -moz-border-radius: 6px;
    -webkit-border-radius: 6px;
    border-radius: 6px;
    -webkit-box-shadow: 0 1px 1px #ccc; 
    -moz-box-shadow: 0 1px 1px #ccc; 
    box-shadow: 0 1px 1px #ccc;         
}

.bordered tr:hover {
    background: #fbf8e9;
    -o-transition: all 0.1s ease-in-out;
    -webkit-transition: all 0.1s ease-in-out;
    -moz-transition: all 0.1s ease-in-out;
    -ms-transition: all 0.1s ease-in-out;
    transition: all 0.1s ease-in-out;     
}    
    
.bordered td, .bordered th {
    border-left: 1px solid #ccc;
    border-top: 1px solid #ccc;
    padding: 10px;
    text-align: left;    
}

.bordered th {
    background-color: #dce9f9;
    background-image: -webkit-gradient(linear, left top, left bottom, from(#ebf3fc), to(#dce9f9));
    background-image: -webkit-linear-gradient(top, #ebf3fc, #dce9f9);
    background-image:    -moz-linear-gradient(top, #ebf3fc, #dce9f9);
    background-image:     -ms-linear-gradient(top, #ebf3fc, #dce9f9);
    background-image:      -o-linear-gradient(top, #ebf3fc, #dce9f9);
    background-image:         linear-gradient(top, #ebf3fc, #dce9f9);
    -webkit-box-shadow: 0 1px 0 rgba(255,255,255,.8) inset; 
    -moz-box-shadow:0 1px 0 rgba(255,255,255,.8) inset;  
    box-shadow: 0 1px 0 rgba(255,255,255,.8) inset;        
    border-top: none;
    text-shadow: 0 1px 0 rgba(255,255,255,.5); 
}

.bordered td:first-child, .bordered th:first-child {
    border-left: none;
}

.bordered th:first-child {
    -moz-border-radius: 6px 0 0 0;
    -webkit-border-radius: 6px 0 0 0;
    border-radius: 6px 0 0 0;
}

.bordered th:last-child {
    -moz-border-radius: 0 6px 0 0;
    -webkit-border-radius: 0 6px 0 0;
    border-radius: 0 6px 0 0;
}

.bordered th:only-child{
    -moz-border-radius: 6px 6px 0 0;
    -webkit-border-radius: 6px 6px 0 0;
    border-radius: 6px 6px 0 0;
}

.bordered tr:last-child td:first-child {
    -moz-border-radius: 0 0 0 6px;
    -webkit-border-radius: 0 0 0 6px;
    border-radius: 0 0 0 6px;
}

.bordered tr:last-child td:last-child {
    -moz-border-radius: 0 0 6px 0;
    -webkit-border-radius: 0 0 6px 0;
    border-radius: 0 0 6px 0;
}

/* ヘッダー固定 
.fTable { border:solid 1px; }
.fTableHeader { float:left; }
.fTableBody { float:left; height:600px; overflow:auto; }
 */

</style>


<link rel="stylesheet" href="./css/captionText.css" type="text/css" />
<link rel="stylesheet" href="./css/animate.css" />

<!-- 0パディング等-->
<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/jquery.min.js"></script>

<script language="javascript" type="text/javascript">



 function showDetails(obj) {


   var userId = obj.parentNode.id;
   //parentへXDMで送信
   var data = new Object;
   data.action = "find";
   data.userId = userId;

   window.parent.postMessage( data, "*" );

  // window.parent.postMessage( "userId:" + userId, "*" );


 }



window.addEventListener("message", function(e){
  createSettingFiles();
}, false);



function setHeaderButton( className ) {

  var target = document.getElementById(className + "Button" );
  //var oldClass = target.getAttribute( "class" );

  var cnt = 0;
  var list = document.getElementsByName( className );
  for (var i = 0; i < list.length; i++ ) {
      if ( list[ i ].checked ) {
         cnt++;
      }
  }

  countMsg = "";
  if ( cnt > 0 ) {
      countMsg = cnt;
  }
  document.getElementById( className + "Cnt" ).innerHTML = countMsg;

  if ( cnt == 1 ) {
      target.setAttribute( "style", "visibility:visible;" );
      target.setAttribute( "class", "animated fadeIn" );
  } else if ( cnt == 0 ) {
      target.setAttribute( "class", "animated fadeOut" );
  }
}

function execute ( className, programName ) {

  var userIdList = new Array();
  var list = document.getElementsByName( className );
  for (var i = 0; i < list.length; i++ ) {
      if ( list[ i ].checked ) {
         userIdList.push( list[ i ].parentNode.parentNode.id );
      }
  }

  var data = new Object;
  data.action = className;
  data.userId = userIdList.join();
  window.parent.postMessage( data, "*" );

/*
  document.getElementById( "userIds" ).value = userIdList.join();

  var transactionForm = document.getElementById( "transactionForm" );
  transactionForm.setAttribute( "action", programName );
  transactionForm.submit();

  window.parent.postMessage( "refind", "*" );
*/
}



function f_createFile() {

    execute ( "createFile", "./deleteUsers.php" );
}

function f_requestCheck() {

    execute ( "requestCheck", "./deleteUsers.php" );

}


function f_checkCompleted() {

    execute ( "checkCompleted", "./deleteUsers.php" );

}


function f_released() {

    execute ( "released", "./deleteUsers.php" );

}


function f_deleteUsers() {

    execute ( "delete", "./deleteUsers.php" );

}


</script>

</head>
<body>




<table class="bordered fTable" style="font-size:13px">
    <thead class="fTableHeader">

    <tr>
        <th>CD</th>        
        <th>ユーザ名</th>
        <th>追加エンジン</th>
        <th>CDN</th>
        <th>携帯</th>
        <th>PDF</th>
        <th>状態</th>
        <th>リリース予定日</th>
        <th>リリース完了日</th>
        <th>ﾌｧｲﾙ生成<br /><span  id="createFileButton" style="visibility: hidden"><a href="#" title="Morph" class="button blue icon morph" data-icon="GO" onClick="f_createFile()"></a></span>
            <span id="createFileCnt"></span></th>
        <th>ﾁｪｯｸ依頼<br /><span id="requestCheckButton" style="visibility: hidden"><a  href="#" title="Morph" class="button pink icon morph" data-icon="GO" onClick="f_requestCheck()"></a></span>
            <span id="requestCheckCnt"></span></th>
        <th>ﾁｪｯｸ完了<br /><span id="checkCompletedButton" style="visibility: hidden"><a  href="#" title="Morph" class="button orange icon morph" data-icon="GO" onClick="f_checkCompleted()"></a></span>
            <span id="checkCompletedCnt"></span></th>
        <th>ﾘﾘｰｽ済み<br /><span  id="releasedButton" style="visibility: hidden"><a href="#" title="Morph" class="button green icon morph" data-icon="GO" onClick="f_released()"></a></span>
            <span id="releasedCnt"></span></th>
        <th>削除<br /><span  id="deleteButton" style="visibility: hidden"><a href="#" title="Morph" class="button grey icon morph" data-icon="GO" onClick="f_deleteUsers()"></a></span>
            <span id="deleteCnt"></span></th>
    </tr>
    </thead>
    <tbody class="fTableBody" id="userInfos">
$data
    </tbody>
</table>


<!--form action="valiable_deleteUser.php_or_createFils.php" id="transactionForm" name="transactionForm" method="POST" target="msgFrame">
  <input type="hidden" id="userIds" name="userIds" />

</form-->

</body>
</html>

EOF;


echo $html;

// MySQLへの接続を閉じる
mysql_close($connect) or die("MySQL切断に失敗しました。");



?>