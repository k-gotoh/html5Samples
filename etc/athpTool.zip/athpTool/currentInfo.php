<?php

function useDisplay( $use ){
  return $use == "1" ? "あり" : "なし";
}


include '../connect.php';

$db = "hptool";


// MySQLへ接続する
$connect = connect();

  // データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");


$eidArray = array();

$sql = "select eid,name from m_engine order by seq";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
    $eidArray[ $row[ 'eid' ] ] = $row[ 'name' ];
}



$dateFrom = date("Y-m-d");
$dateTo   = date("Y-m-d", strtotime( "+1 week") );


$omote = "";
$ura = "";


$sql = "select * from m_user where plan_date between '" . $dateFrom . "' and '" . $dateTo . "' order by plan_date";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {

    $useEidArray = array();
    $sql = "select eid from t_use_engine where user_id = '" . $row[ 'user_id' ] . "'";
    $resultEid = mysql_query($sql, $connect);
    while ($rowEid = mysql_fetch_assoc($resultEid)) {
        array_push( $useEidArray, $eidArray[ $rowEid[ 'eid' ] ] );
    }
    $eidDisplay = implode( $useEidArray );
    
    $status = "";
    switch ($row[ 'status' ] ) {
        case "1":
            $status = "登録中";
            break;

        case "2":
            $status = "開発チェック中";
            break;

        case "3":
            $status = "リリース待ち";
            break;

        case "4":
            $status = "リリース済み";
            break;

        case "9":
            $status = "キャンセル";
            break;
    }

    $omote .= "<tr><td>";
    $omote .= "<a href='#' onClick='return showDetail(this)' name=" . $row[ "user_id" ] . " class='textFlip'>";
    $omote .= $row[ "client_name" ] . "(" . $row[ "plan_date" ] . ")</a></td>";
    $omote .= "<td>" . $status . "</td></tr>";


    $ura .= "<input type='hidden' id='" . $row[ "user_id" ] . "' ";
    $ura .= "value=\"<p style='margin:2px;0px;0px;2px'>●" . $row[ "client_name" ] . "</p><table border='0' align='center' height='280px' >";
    $ura .= "<tr><td width='150px'>リリース予定日</td><td>" . $row[ "plan_date" ] . "</td></tr>";
    $ura .= "<tr><td>状態</td><td>" . $status . "</td></tr>";
    $ura .= "<tr><td>追加エンジン</td><td>" . $eidDisplay . "</td></tr>";
    $ura .= "<tr><td>CDN</td><td>" . useDisplay( $row[ 'use_cdn' ] ) . "</td></tr>";
    $ura .= "<tr><td>携帯</td><td>" . useDisplay( $row[ 'use_mobile' ] ) . "</td></tr>";
    $ura .= "<tr><td>PDF</td><td>" . useDisplay( $row[ 'use_pdf' ] ) . "</td></tr></table>\"";
    $ura .= " />";

}




$html = <<< EOF
<!doctype html>
<html lang="en-us" dir="ltr" class="no-js">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="./css/main.css" />
<link rel="stylesheet" href="./css/animate.css" />

<script src="./js/jquery.min.js"></script>
<script src="./js/jquery-ui.min.js"></script>

<!--script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js"></script-->
<!--script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.min.js"></script-->

<style type="text/css">
body { background: #fff; }
		.panel {
			float: left;
			width: 600px;
			height: 600px;
			margin: 20px;
			position: relative;

			
			-webkit-perspective: 600px;
			-moz-perspective: 600px;
		}
		/* -- make sure to declare a default for every property that you want animated -- */
		/* -- general styles, including Y axis rotation -- */
		.panel .front {
			float: none;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 900;
			width: inherit;
			height: inherit;
			border: 1px solid #ccc;
			/* background: #6b7077; */
                        background: #87c0de;
			text-align: center;

			-moz-box-shadow: 0 1px 5px rgba(0,0,0,0.9);
			-webkit-box-shadow: 0 1px 5px rgba(0,0,0,0.9);
			box-shadow: 0 1px 5px rgba(0,0,0,0.9);

			-webkit-transform: rotateX(0deg) rotateY(0deg);
			-webkit-transform-style: preserve-3d;
			-webkit-backface-visibility: hidden;

			-moz-transform: rotateX(0deg) rotateY(0deg);
			-moz-transform-style: preserve-3d;
			-moz-backface-visibility: hidden;

			/* -- transition is the magic sauce for animation -- */
			-o-transition: all .4s ease-in-out;
			-ms-transition: all .4s ease-in-out;
			-moz-transition: all .4s ease-in-out;
			-webkit-transition: all .4s ease-in-out;
			transition: all .4s ease-in-out;
		}
		.panel.flip .front {
			z-index: 900;
			border-color: #eee;
			background: #333;

			-webkit-transform: rotateY(180deg);
			-moz-transform: rotateY(180deg);
			
			-moz-box-shadow: 0 15px 50px rgba(0,0,0,0.2);
			-webkit-box-shadow: 0 15px 50px rgba(0,0,0,0.2);
			box-shadow: 0 15px 50px rgba(0,0,0,0.2);
		}
		
		.panel .back {
			float: none;
			position: absolute;
			top: 0;
			left: 0;
			z-index: 800;
			width: inherit;
			height: inherit;
			border: 1px solid #ccc;
			background: #333;
			
			
			-webkit-transform: rotateY(-180deg);
			-webkit-transform-style: preserve-3d;
			-webkit-backface-visibility: hidden;

			-moz-transform: rotateY(-180deg);
			-moz-transform-style: preserve-3d;
			-moz-backface-visibility: hidden;

			/* -- transition is the magic sauce for animation -- */
			-o-transition: all .4s ease-in-out;
			-ms-transition: all .4s ease-in-out;
			-moz-transition: all .4s ease-in-out;
			-webkit-transition: all .4s ease-in-out;
			transition: all .4s ease-in-out;
		}
		
		.panel.flip .back {
			z-index: 1000;
			/* background: #80868d; */
                        background: #80868d;
			-webkit-transform: rotateX(0deg) rotateY(0deg);
			-moz-transform: rotateX(0deg) rotateY(0deg);

			box-shadow: 0 15px 50px rgba(0,0,0,0.2);
			-moz-box-shadow: 0 15px 50px rgba(0,0,0,0.2);
			-webkit-box-shadow: 0 15px 50px rgba(0,0,0,0.2);
		}
		
		/* -- X axis rotation for click panel -- */
		.click .front {
			cursor: pointer;
			-webkit-transform: rotateX(0deg);
			-moz-transform: rotateX(0deg);
		}
		.click.flip .front {
			-webkit-transform: rotateX(180deg);
			-moz-transform: rotateX(180deg);
		}
		.click .back {
			cursor: pointer;
			-webkit-transform: rotateX(-180deg);
			-moz-transform: rotateX(-180deg);
		}
		.click.flip .back {
			-webkit-transform: rotateX(0deg);
			-moz-transform: rotateX(0deg);
		}

    /* -- contact panel -- */
    .contact {
      width: 400px;
      height: 300px;
    }
		
		/* -- diagonal axis rotation -- */
		.diagonal .front {
			-webkit-transform: rotate3d(45,45,0,0deg);
			-moz-transform: rotate3d(45,45,0,0deg);
		}
		.diagonal .front:hover {
			/* for the patient :) */
			-webkit-transition-duration: 10s;
			   -moz-transition-duration: 10s;
			-webkit-transition-delay: 0s;
			   -moz-transition-delay: 0s;

			-webkit-transform: rotate3d(45,45,0,-36deg);
			-moz-transform: rotate3d(45,45,0,-36deg);
		}

		.diagonal.flip .front,
		.diagonal.flip .front:hover {
			-webkit-transform: rotate3d(-45,-45,0,150deg);
			-moz-transform: rotate3d(-45,-45,0,150deg);

			-o-transition: all .4s ease-in-out;
			-ms-transition: all .4s ease-in-out;
			-moz-transition: all .4s ease-in-out;
			-webkit-transition: all .4s ease-in-out;
			transition: all .4s ease-in-out;
		}

		.diagonal .front .message {
		  opacity: 0;
			font-size: 1.4em;
		}
		.diagonal .front:hover .message {
			opacity: .4;
			-webkit-transition-duration: 12s;
			   -moz-transition-duration: 12s;
			-webkit-transition-delay: 4s;
			   -moz-transition-delay: 4s;
			-webkit-transform: translateX(-30px) translateZ(40px) scale(1.4);
			   -moz-transform: translateX(-30px) translateZ(40px) scale(1.4);
		}
		.diagonal.flip .front .message {
			-webkit-transition-duration: 1s;
		  -webkit-transform: translateZ(0px) scale(.5);
		}

		.diagonal .back {
			-webkit-transform: rotate3d(45,45,0,-180deg);
			-moz-transform: rotate3d(45,45,0,-180deg);
		}
		.diagonal.flip .back {
			-webkit-transform: rotate3d(45,45,0,-30deg);
			-moz-transform: rotate3d(45,45,0,-30deg);
		}

    /* -- swing like a gate -- */
    .swing .front,
    .swing .back {
      width: 140px;
      -webkit-backface-visibility: visible;
         -moz-backface-visibility: visible;
      -webkit-transition-duration: 1s;
         -moz-transition-duration: 1s;
      -webkit-transform-origin: 170px 0;
         -moz-transform-origin: 170px 0;
    }
    .swing .front {
      -webkit-transform: rotateY(0deg);
         -moz-transform: rotateY(0deg);
    }
    .swing .back {
      background-color: #555; /* hiding this side, so get darker */
      -webkit-transform: rotateY(-180deg) translateX(198px) translateZ(2px);
         -moz-transform: rotateY(-180deg) translateX(198px) translateZ(2px);
    }

    .swing.flip .front {
      background-color: #222; /* hiding this side, so get darker */
      -webkit-transform: rotateY(180deg);
         -moz-transform: rotateY(180deg);
    }
    .swing.flip .back {
      background-color: #80888f;
      -webkit-transform: rotateY(0deg) translateX(198px) translateZ(2px);
         -moz-transform: rotateY(0deg) translateX(198px) translateZ(2px);
    }
		
		
		/* -- cosmetics -- */
		.panel .pad {padding: 0 15px; }
		.panel.flip .action {display: none; }
		.block ol li {text-align: left; margin: 0 0 0 28px; }
		.block .action {display: block; padding: 3px; background: #333; text-align: right; font-size: .8em; opacity: 0; position: absolute; cursor: pointer; -webkit-transition: opacity .2s linear; }
		.block:hover .action {opacity: .7; }
		.circle div {border-radius: 100px; }
		.circle div h2 {padding-top: 3em; text-align: center; }



.anime{
  font:35px bold;
  color:#000;
  padding:25px;
-webkit-transition: 0.3s ease-in-out;
 text-align:center;
}

.anime:hover{
text-shadow: 0 40px #ff0000,
0 -40px #0000ff,
100px 0 #008000,
-100px 0 #ffc0cb;
}


table.textFlip { color:#444444;
}

strong.textFlip { color:#fff;
}

a.textFlip { text-decoration: none; 
border-bottom: 1px #55f dotted;
   padding-bottom: 1px;
}

</style>
<script type="text/javascript">
		$(document).ready(function(){
			
			// set up hover panels
			// although this can be done without JavaScript, we've attached these events
			// because it causes the hover to be triggered when the element is tapped on a touch device

			
			// set up contact form link
			$('.contact .action').click(function(e){
				$('.contact').addClass('flip');
				e.preventDefault();
			});
			$('.contact .edit-submit').click(function(e){
				$('.contact').removeClass('flip');
				// just for effect we'll update the content
				e.preventDefault();
			});
			
		});

msg = "";
function showDetail(obj) {
  document.getElementById("paper").play();
  document.getElementById("contact").innerHTML = document.getElementById(obj.name).value;
  msg="fill";

}

function showError() {
  if ( !msg ) {
    document.getElementById("paper").play();
    document.getElementById("contact").innerHTML = "<table border='0' align='center' height='300px' ><tr><td><span class='anime'>m9（｀・ω・´)</span><br />　　ユーザ名を選択してください。</td></tr></table>";

  }
  msg = "";

}
</script>


</head>
<body>

<br /><br /><br /><br /><br />

	<div class="contact panel">

		<div class="front animated flipInY" onClick="return showError()">
                  <div class="contact action">
<br>
<strong class="textFlip">【一週間以内にリリース予定のお客様】</strong><br /><br />
<table border="0" align="center" class="textFlip">
$omote
</table>
                  </div>

		</div>
		<div class="back edit-submit" id="contact">
			<div class="pad">

			</div>
		</div>
	</div>


$ura

<audio id="paper" preload="auto">
<source src="./SE/paper2.mp3" type="audio/mp3"/>
</audio>


<script type="text/javascript">
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
	try {
		var pageTracker = _gat._getTracker("UA-432773-11");
		pageTracker._trackPageview();
	} catch(err) {}
</script>


</body>
</html>
EOF;


echo $html;

// MySQLへの接続を閉じる
mysql_close($connect) or die("MySQL切断に失敗しました。");



?>