<?php


include '../connect.php';

$db = "hptool";




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  $eidList = array();
  $nameList =  array();
  $forceList =  array();

  $sql = "SELECT * FROM m_engine order by seq";
  $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
  while ($row = mysql_fetch_assoc($result)) {
    array_push( $eidList, $row[ 'eid' ] );
    array_push( $nameList, $row[ 'name' ] );
    array_push( $forceList, $row[ 'force_flg' ] );

  }


  if ( count( $eidList ) == 0 ) {
    $eidList[0] = "";
    $nameList[0] = "";
    $forceList[0] = "false";
  }


$data = "";
for ( $i = 1; $i < count($eidList); $i++ ) {
  $num = str_pad( $i + 1 ,2 ,"0", STR_PAD_LEFT);
  $checked = ( $forceList[$i] == "1" )?"checked":"";
  $data .= <<< DATA_EOF
    <div>
    <span class="">$num</span><input type="text" class="rounded eid" size="10" onblur="saveengine()" placeholder="EIDを入力"value="$eidList[$i]" required="">
　<input type="text" class="rounded eName" size="50" onblur="saveengine()" placeholder="名称を入力" value="$nameList[$i]" required="">
    <span class="caption">必須</span><input type="checkbox" class="rounded force" $checked/>
<a href="#" class="button delete" onclick="return lineDel(this)" >削除</a>
</div>
DATA_EOF;

}



$checked  = ( $forceList[0] == "1" )?"checked":"";

$html = <<< EOF
<!DOCTYPE html>
<html>
<head>
<title>@HP自動化ツール</title>
<link rel="shortcut icon" href="./favicon.ico"> 
<meta charset="UTF-8" />

<link rel="stylesheet" href="./css/header.css" />
<link rel="stylesheet" href="./css/captionText.css" type="text/css" />
<link rel="stylesheet" href="./css/roundedTextBox.css" type="text/css" />
<!--link rel="stylesheet" href="./css/pageCengine.css" type="text/css" /-->
<link rel="stylesheet" type="text/css" href="./css/style4.css" />
<style type="text/css">
span.error {
   color: red;
  }
 
div.error {
   color: red;
    -webkit-animation-name: 'rotate';
	-webkit-animation-duration: 1s;
	-webkit-animation-timing-function: ease;
}


div.shadow{
  color:#fff;
  padding:10px;
  background:#ffc0cb;
  -webkit-transition: 0.5s ease-in-out;
  -moz-box-shadow: 10px 3px 15px #800000;
  -webkit-box-shadow: 10px 3px 15px #800000;
}

  @-webkit-keyframes 'rotate' {
    0% { -webkit-transform: rotate(0deg); }
    33% { -webkit-transform: rotate(0.5deg); }
    66% { -webkit-transform: rotate(-0.5deg); }
    100% { -webkit-transform: rotate(0deg); }
  }
}





</style>
<link rel="stylesheet" href="./css/button.css" type="text/css" />

<link rel="stylesheet" href="./css/title.css" type="text/css" />
<link rel="stylesheet" href="./css/animate.css" />

<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/settingHeader2.js"></script>
<script type="text/javascript" src="./js/jquery-1.9.0.js"></script>
<script type="text/javascript" src="./js/beforeUnload.js"></script>

<script language="javascript" type="text/javascript">

    var insertHtml = "    <span>01</span><input type='text' class='rounded eid'size='10' onBlur='saveengine()' placeholder='EIDを入力' required />　" +
" <input type='text' class='rounded eName' size='50' onBlur='saveengine()' placeholder='名称を入力' required />" +
"    <span class='caption' />必須</span><input type='checkbox' class='rounded force'>" +
"<a href='#' class='button delete'  onClick='return lineDel(this)'>削除</a>";

    currentSelect = "";

    function lineAdd() {
      var target = document.getElementById("lineLast");
      var newElement = document.createElement("div"); 
      newElement.setAttribute("name","changeMe");
      newElement.innerHTML = insertHtml;
      target.insertBefore(newElement, null);
      saveengine();
      var changeTarget = document.getElementsByName("changeMe").item(0);
      changeTarget.setAttribute("name","");
      changeTarget.setAttribute("class","animated fadeInDown");
      //renumber();
    }


    function lineDel(obj) {
      var parentObj = obj.parentNode;
      parentObj.setAttribute("class","animated fadeOutUp");
      setTimeout( function(){  
           parentObj.setAttribute("class","");
           parentObj.parentNode.removeChild(obj.parentNode);
           saveengine();
      }, 500 );


      //renumber();

    }


    function renumber(errNumberList)  {
      var i = 1;
      //var engineList = document.getElementById("lineLast");
      var engineNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(engineNode) {
        i++;
        engineNode.getElementsByTagName('span').item(0).innerHTML = toZeroPadding(i, 2);
        if (errNumberList.join().match(i)) {
           engineNode.getElementsByTagName('span').item(0).setAttribute("class","error");
           engineNode.setAttribute("class","error");
        } else {
           engineNode.getElementsByTagName('span').item(0).setAttribute("class","");
           engineNode.setAttribute("class","");
        }


        engineNode = engineNode.nextElementSibling;
      }
    }

/*   */
    function dataPost() {
      var eidList = new Array();
      var nameList = new Array();
      var forceList = new Array();


      eidList.push( document.getElementById("eidFirst").value  );
      nameList.push( document.getElementById("eNameFirst").value  );
      forceList.push( document.getElementById("forceFirst").checked  );


      var engineNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(engineNode) {
        eidList.push( engineNode.getElementsByClassName('eid').item(0).value );
        nameList.push( engineNode.getElementsByClassName('eName').item(0).value );
        forceList.push( engineNode.getElementsByClassName('force').item(0).checked );

         
   
        engineNode = engineNode.nextElementSibling;
      }
      document.getElementById("eidSave").value = eidList.join();
      document.getElementById("nameSave").value = nameList.join();
      document.getElementById("forceSave").value = forceList.join();

      document.frm.submit();

      frameAppear();

    }

    function saveengine() {
      var engineList = new Array();
      var errNumberList = new Array();
      var i = 1;

      var inputText = document.getElementById("eidFirst").value;
      if (inputText) {
          engineList.push(inputText);
      } else {
          errNumberList.push(i);
      }

      var engineNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(engineNode) {
        var engineInputNodes = engineNode.getElementsByTagName('input');
        
        
        var textValue = engineInputNodes.item(0).value.replace(/(^\s+)|(\s+$)/g, ""); //trim
        if (textValue) {
            i++;
            if (!engineList.join().match(textValue)) { 
              engineList.push(textValue);
            } else {
              errNumberList.push(i);
            }
         
        }
   
        engineNode = engineNode.nextElementSibling;
      }

      document.getElementById("engineSave").value = engineList.join();
      renumber(errNumberList);

    }


    function getengineText() {
       alert(document.getElementById("engineSave").value);

    }

    function showDetail(obj) {
       var enginetext = obj.parentNode.getElementsByTagName('input').item(0).value;

       if (currentSelect) {
          currentSelect.setAttribute("class","");
       }
       currentSelect = obj.parentNode;
       currentSelect.setAttribute("class","shadow");

    }


function frmSubmit(){
    document.frm.submit();
}



function init() {
  createHeader();
}
 
 </script>
</head>
<body onLoad="init()">
<ul id='nav'></ul>

<table border="0"><tr><td width="350px">
<p class="title"> エンジン登録</p></td>
</tr></table>


<form name="frm" action="./engineSave.php" method="POST" target="msgFrame">


  <div>
  <a href="#" class="button add"  onClick="return lineAdd()">行追加</a>

  </div>
  <div>
    <span>01</span><input type='text' class='rounded' id='eidFirst' size='10' onBlur='saveengine()' placeholder='EIDを入力' value="$eidList[0]"required />　
    <input type='text' class='rounded' id="eNameFirst" size='50' onBlur='saveengine()' placeholder='名称を入力' value="$nameList[0]" required />
    <span class="caption" />必須<span/><input type="checkbox" class="rounded" id="forceFirst" $checked>
  </div>

  <div id="lineLast">$data</div>

  <input type="hidden" name="engineSave" id="engineSave">
  <input type="hidden" name="eidSave" id="eidSave">
  <input type="hidden" name="nameSave"id="nameSave">
  <input type="hidden" name="forceSave"id="forceSave">

</form>
</body>
</html>
EOF;


echo $html;

  //結果保持用メモリを開放する
  mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>