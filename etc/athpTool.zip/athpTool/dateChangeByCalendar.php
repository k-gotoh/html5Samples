<?php


function msg( $msg, $end ) {

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
<script>
function sendMsg() {
  var str = document.getElementById('end').value;


  if ( str == 'ok' ) {
     window.parent.postMessage( "updated", "*" );
  }
  
}
</script>
</head>
<body onload='sendMsg()'>
<span>$msg</span>
<input type='hidden' id='end' value='$end'/>
</body>
</html>
EOF;

echo $html;

}

include '../connect.php';

$db = "hptool";

$msg = "";
$end = "faild";

// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");


$data = $_POST[ 'saveData' ];

$dataList = explode( ",", $data );


for ( $i = 0; $i < count( $dataList ); $i++ ) {
    
    $chk = explode( ":", $dataList[ $i ] );
    $ymd = explode( "/", $chk[1]);
    if ( strlen( $ymd[1] ) == 1 ) {
        $ymd[1] = "0" .  $ymd[1];
    } 
    if ( strlen( $ymd[2] ) == 1 ) {
        $ymd[2] = "0" .  $ymd[2];
    } 

    $d = implode( "-", $ymd );
    $sql = "update m_user set plan_date = '" . $d . "' where user_id = " . $chk[0];
    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
        print( "更新に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) . " " . $sql );
        return;
    }

}



  //結果保持用メモリを開放する
  //mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");

  $msg .= "更新しました";
  $end = "ok";
  msg( $msg , $end );

?>