<?php

require_once("Mail.php");

require_once("../connect.php");
require_once("../settingMail.php");
//include '../connect.php';

$db = "hptool";




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

mb_language("Japanese");
mb_internal_encoding("UTF-8");

$params = settingMail();

// PEAR::Mailのオブジェクトを作成
// ※バックエンドとしてSMTPを指定
$mailObject = Mail::factory("smtp", $params);

// 送信先のメールアドレス
$recipients = "gotoh@yk.rim.or.jp";

// メールヘッダ情報を連想配列としてセット
$headers = array(
  "To" => "gotoh@yk.rim.or.jp",         // →ここで指定したアドレスには送信されない
  "From" => "gotoh@yk.rim.or.jp",
  "Subject" => mb_encode_mimeheader("メール件名2") // 日本語の件名を指定する場合、mb_encode_mimeheaderでエンコード
);

// メール本文
$body = "日本語メールの本文2。";

// 日本語なのでエンコード
$body = mb_convert_encoding($body, "ISO-2022-JP", "UTF-8");

print "<span style='font-size:12px;color:red;'>";

// sendメソッドでメールを送信
$ret = $mailObject->send($recipients, $headers, $body);
if(PEAR::isError($ret)) {
  die("エラーメッセージ：".$ret->getMessage());
} else {
  print "依頼メールを送信しました。<br />";
}



  //結果保持用メモリを開放する
//  mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");

print "</span>";
?>