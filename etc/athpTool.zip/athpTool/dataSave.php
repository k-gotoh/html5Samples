<?php

function dicArraySet( $id, $dicEid, $type ){

    $useDicArray = array();

    if ( !isset( $dicEid[ $type ] ) ) {
        return;
    }

    $useDicRec = $dicEid[ $type ];
    $useDicList = explode( ",", $useDicRec);


    if ( count ( $useDicList ) == 0 || $useDicList[0] == "" ) {
        return;
    }


    for ( $j = 0; $j < count ( $useDicList ); $j++ ) {
        $useDic = explode( "\t", $useDicList[ $j ] );
        array_push( $useDicArray, $useDic[0] );
    }

    return $useDicArray;
}

function dicAdd ( $connect, $id, $dicEid, $status, $useDicArray ) {

    for ( $i = 0; $i < count ( $useDicArray ); $i++ ) {
        $sql = "insert into t_use_dic value('" . $id . "', '" . $dicEid . "', '" . $status . "', " . $i . ", '" . $useDicArray[ $i ] . "')";
        $result = mysql_query( $sql, $connect );
        if ( !$result ) {
            print( "追加に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) . "SQL:" . $sql );
            return;
        }
    }

}


include '../connect.php';

$db = "hptool";


$id = $_POST[ 'idKey' ];

$new = false;
if ( $id == 0 ) {
  $new = true;
}


print "<span style='font-size:12px;color:red;'>";
//エンジン

//辞書

//対象外url

// MySQLへ接続する
$connect = connect();

  // データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");
mysql_query( "begin", $connect );

//基本設定
$basicJson = $_POST[ 'basic' ];
$basic = json_decode( $basicJson , true );

$clientId     = $basic['clienetID'];
$clienetName  = $basic['clienetName'];
$settingId    = $basic['settingID'];
$planDate     = $basic['planDate'];
$completeDate = '';
$useCDN       = $basic['useCDN'] ? '1' : '0';
$useMobile    = $basic['useCellular'] ? '1' : '0';
$usePDF       = $basic['usePDF'] ? '1' : '0';
$cancelFlg    = $basic['cancel'] ? '1' : '0';
$cancelDate   = '';

$column  = "";
$value   = "";

if ( !$new ) {
    $sql = "delete from m_user where user_id = " . $id;
    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
        print( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );
        return;
    }

    $column = "user_id,";
    $value = $id . ",";
}



$sql  = "insert into m_user (";
$sql .= $column;
$sql .= " client_id";
$sql .= ",client_name";
$sql .= ",setting_id";
$sql .= ",plan_date";
$sql .= ",complete_date";
$sql .= ",use_cdn";
$sql .= ",use_mobile";
$sql .= ",use_pdf";
$sql .= ",cancel_flg";
$sql .= ",cancel_date";
$sql .= ") ";
$sql .= "value(";
$sql .= $value;
$sql .= " '" . $clientId . "'";
$sql .= ",'" . $clienetName . "'";
$sql .= ",'" . $settingId . "'";
$sql .= ",'" . $planDate . "'";
$sql .= ",'" . $completeDate . "'";
$sql .= ",'" . $useCDN . "'";
$sql .= ",'" . $useMobile . "'";
$sql .= ",'" . $usePDF . "'";
$sql .= ",'" . $cancelFlg . "'";
$sql .= ",'" . $cancelDate . "'";
$sql .= ")";

$result = mysql_query( $sql, $connect );
if ( !$result ) {
    print( "追加に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) . " " . $sql );
    return;
}

if ( $id == 0 ) {
  $id = mysql_insert_id();
}


//対象url
$urlArray = array();
$booleanArray = array();

$useUrlJson = $_POST[ 'urlList' ];
$useUrl = json_decode( $useUrlJson , true );

array_push( $urlArray, $useUrl['urlFirst'] );
array_push( $booleanArray, $useUrl['cellularFirst'] ? "1" : "0"  );

if ( !is_null($useUrl['urlList']) && $useUrl['urlList'] != "" ) {
  $list = explode( "," , $useUrl['urlList'] );
  for ( $i = 0; $i < count( $list ); $i++ ) {
    array_push( $urlArray, $list[ $i ] );
  }
}
if ( !is_null($useUrl['booleanList']) && $useUrl['booleanList'] != "" ) {
  $list = explode( "," , $useUrl['booleanList'] );
  for ( $i = 0; $i < count( $list ); $i++ ) {
    array_push( $booleanArray, $list[ $i ] );
  }
}


if ( !$new ) {
    $sql = "delete from t_use_url where user_id = " . $id;
    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
        print( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );
        return;
    }
}

if ( count( $urlArray ) > 0 ) {
    for ( $i = 0; $i < count( $urlArray ); $i++ ) {

        $sql  = "insert into t_use_url value(";
        $sql .= $id;
        $sql .= "," . $i;
        $sql .= ", '" . $urlArray[ $i ] . "'";
        $sql .= ", '" . $booleanArray[ $i ] . "'";
        $sql .= ")";

        $result = mysql_query( $sql, $connect );
        if ( !$result ) {
            print( "追加に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) . " " . $sql );
            return;
        }
    }
}

//エンジン


$useEngineArray = array();
$useEngineJson = $_POST[ 'selectedEID' ];
$useEngine = json_decode( $useEngineJson , true );

//if ( !is_null( $useEngine[ 'selectedEID' ] ) && $useEngine[ 'selectedEID' ] != "" ) {
    $useEngineArray = explode( ",", $useEngine['selectedEID'] );
//}

if ( !$new ) {
    $sql = "delete from t_use_engine where user_id = " . $id;
    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
        print( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );
        return;
    }
}

if ( count( $useEngineArray ) > 0 ) {
    for ( $i = 0; $i < count( $useEngineArray ); $i++ ) {


        $chk = explode( ":", $useEngineArray[ $i ] );
        if ( count( $chk ) < 2 ) {
            break;
        }

        if ( $chk[1] == "1" ) {
            $sql  = "insert into t_use_engine value(";
            $sql .= $id;
            $sql .= ", '" . $chk[0] . "'";
            $sql .= ")";

            $result = mysql_query( $sql, $connect );
            if ( !$result ) {
                print( "追加に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) . " " . $sql );
                return;
            }
        }

    }
}


//辞書
$dicEidArray = array();
$useDicArray = array();
$unuseDicArray = array();

$sql = "select eid from m_engine";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {

    array_push( $dicEidArray, $row[ 'eid' ] );
}

for ( $i = 0; $i < count( $dicEidArray ); $i++ ) {

    $eid = $dicEidArray[ $i ];
    if ( !isset( $_POST[ $eid ] ) ) {
        continue;
    }

    $dicEidJson = $_POST[ $eid ];

    $dicEid = json_decode( $dicEidJson , true );

    $useDicArray = dicArraySet( $id, $dicEid, "useDic" );
    $unuseDicArray = dicArraySet( $id, $dicEid, "nonuseDic" );

    if ( !$new ) {
        $sql = "delete from t_use_dic where user_id = '" . $id . "' and eid = '" . $eid . "'";

        $result = mysql_query( $sql, $connect );
        if ( !$result ) {
            print( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );
            return;
        }

    }
  
    dicAdd ( $connect, $id, $eid, "0", $useDicArray );
    dicAdd ( $connect, $id, $eid, "1", $unuseDicArray );

}



//対外象url
$unuseUrlArray = array();
$unuseUrlJson = $_POST[ 'excludeUrlList' ];
$unuseUrl = json_decode( $unuseUrlJson , true );

$unuseUrlArray = array();
array_push( $unuseUrlArray, $unuseUrl['urlFirst']);
if ( !is_null($unuseUrl['urlList']) && $unuseUrl['urlList'] != "" ) {
  $list = explode( ",", $unuseUrl['urlList'] );
  for ( $i = 0; $i < count( $list ); $i++ ) {
    array_push( $unuseUrlArray, $list[ $i ] );
  }
}


if ( !$new ) {
    $sql = "delete from t_unuse_url where user_id = " . $id;
    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
        print( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );
        return;
    }
}

if ( count( $unuseUrlArray ) > 0 ) {
    for ( $i = 0; $i < count( $unuseUrlArray ); $i++ ) {

        $sql  = "insert into t_unuse_url value(";
        $sql .= $id;
        $sql .= "," . $i;
        $sql .= ", '" . $unuseUrlArray[ $i ] . "'";
        $sql .= ")";

        $result = mysql_query( $sql, $connect );
        if ( !$result ) {
            print( "追加に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) . " " . $sql );
            return;
        }
    }
}

//履歴

$now = "";
if ( $new ) {
    $now = date( "Y-m-d H:i:s" );
    $sql = "insert into t_user_history value(" . $id . ", '" . $now . "','1', '')";
    mysql_query( $sql, $connect ) or die("追加に失敗しました。" . $sql);
}

mysql_query( "commit", $connect );

$msg =  "正常に終了しました";

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
<script>
function sendParent() {

    var data = new Object;
    data.action = "saved";
    data.history = "$now";
    data.id = $id;
    window.parent.postMessage( data ,"*");
}
</script>
</head>
<body onload="sendParent()">
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

//結果保持用メモリを開放する
//mysql_free_result($result);
mysql_close($connect) or die("MySQL切断に失敗しました。");


print ( "</span>" );
?>