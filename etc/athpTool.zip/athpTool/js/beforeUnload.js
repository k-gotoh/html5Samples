
$(function() {
  // フォームの入力欄が更新されたかどうかを表すフラグです。

  var isChanged = false;
  $(window).bind("beforeunload", function() {
    console.log(isChanged);
    if (isChanged) {
      // isChangedフラグがtrueの場合、つまり入力内容が変更されていた
      // 場合のみ文字列を返すようにします。

      return "データが変更されている可能性がありますが、このページから移動しますか？";
    }
  });
 
  $("form input, form select, form textarea,li").change(function() {
    // 入力内容が更新されている場合は、isChangedフラグをtrueにします。
    isChanged = true;
  });
 
  $("button[type=submit]").click(function() {
    // フォームをサブミットする前にフラグを落とします。
    // ※ これをやらないと、サブミット時に確認メッセージが表示されてしまいます。
    isChanged = false;
  });
})