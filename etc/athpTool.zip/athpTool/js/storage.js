
function setStorage( key, data ){
    var str = JSON.stringify( data );
    localStorage.setItem( key, str );

}
 
function getStorage( key ){

    var str = localStorage.getItem( key );
    var data = JSON.parse( str );
    return data;
}
