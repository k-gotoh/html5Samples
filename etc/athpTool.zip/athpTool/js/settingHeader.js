document.write("<ul id='nav'>");
document.write(" <li><a href='./userList.html'>ユーザ一覧</a></li>");
document.write(" <li><a href='./tantosha.php'>担当者マスタ</a></li>");
document.write(" <li><a href='./engine.php'>エンジンマスタ</a></li>");
document.write(" <li><a href='./dic.php'>辞書マスタ</a></li>");
document.write(" <li><a href='./charSet.php'>文字コード</a></li>");
document.write(" <li><a href='./calendar.php'>カレンダー</a></li>");
document.write("</ul>");
