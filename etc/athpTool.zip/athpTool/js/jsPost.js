/**
*
* @param1 : arr 連想配列 key=パラメタ名 value=データ
* @param2 : action 渡すプログラム名
* @param3 : target (不要な場合はnull)
*/

function jsPost( arr, action, target ) {
    var form = document.createElement( 'form' );
    document.body.appendChild( form );
    if (arr.length == 0 ) {
      return;
    }

   for(var key in arr) {
     var input = document.createElement( 'input' );
     input.setAttribute( 'type' , 'hidden' );
     input.setAttribute( 'name' , key );
     input.setAttribute( 'value' , arr[ key ] );
     form.appendChild( input );
  }
  form.setAttribute( 'action' , action );
  form.setAttribute( 'method' , 'post' );
  if ( target ) {
    form.setAttribute( 'target' , target );
  }

  form.submit();

  setTimeout( function() {
    document.body.removeChild( form );
  }, 300);
}