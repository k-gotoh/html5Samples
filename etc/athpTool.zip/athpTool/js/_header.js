document.write("<ul id='nav'>");
document.write(" <li><a href='./userList.html'>ユーザ一覧</a></li>");
document.write(" <li><a href='./basicSetting.html'>基本設定</a></li>");
document.write(" <li><a href='./urlSetting.html'>URL設定</a></li>");
document.write(" <li><a href='./engineSetting.html'>エンジン設定</a></li>");
document.write(" <li><a href='./excludeUrlSetting.html'>対象外URL設定</a></li>");
//document.write(" <li><a href='./charSetSetting.html'>文字コード設定</a></li>");

document.write(" <span class='animated fadeIn'><a class='a_demo_four' href='#' style='top:4px;left:270px;font-size:16px;' onClick=\"sendServer( \'dataSave.php\' ,\'msgFrame)\' \" >　登録　</a></span>");

document.write("</ul>");

