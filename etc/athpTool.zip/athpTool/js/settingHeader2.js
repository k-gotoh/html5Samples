function headerTitileLi( hrefStr, text ) {
	var liElement = document.createElement( "li" );
	var aElement = document.createElement( "a" );
	aElement.setAttribute( "href", hrefStr );
//	aElement.setAttribute( "onclick", "pageMove('" + hrefStr + "')" );
	aElement.innerHTML = text;
	liElement.appendChild( aElement );
	
	return liElement;
}


function createHeader() {
	var ulElement = document.getElementById( "nav" );
	
	ulElement.appendChild( headerTitileLi( "./userList.html", "ユーザ一覧" ) );
	ulElement.appendChild( headerTitileLi( "./tantosha.php", "担当者マスタ" ) );
	ulElement.appendChild( headerTitileLi( "./engine.php", "エンジンマスタ" ) );
	ulElement.appendChild( headerTitileLi( "./dic.php", "辞書マスタ" ) );
//	ulElement.appendChild( headerTitileLi( "./charSet.php", "文字コード" ) );
	ulElement.appendChild( headerTitileLi( "calendar.php", "カレンダー" ) );


        var urlWk = location.href.substring(location.href.lastIndexOf("/")+1,location.href.length);
        var url = urlWk.split("#");
        if ( url[0] != "userList.html" ) {
       	    var spanElement = document.createElement( "span" );
	    spanElement.setAttribute( "class", "animated fadeIn" );
	    var aElement = document.createElement( "a" );
	    aElement.setAttribute( "href", "#" );
	    aElement.setAttribute( "class", "a_demo_four" );
	    aElement.setAttribute( "style", "top:-14px;left:30px;font-size:14px;" );
//	    aElement.setAttribute( "onclick", "sendServer( 'dataSave.php' ,'msgFrame', true )" );
            aElement.setAttribute( "onclick", "dataPost()" );
	    aElement.innerHTML = "　登録　";
	    spanElement.appendChild( aElement );
  	    ulElement.appendChild( spanElement );
	
	}

        var iframe = document.createElement( "iframe" );
        iframe.setAttribute( "id", "msgFrame" );
        iframe.setAttribute( "name", "msgFrame" );
        iframe.setAttribute( "width", "300px" );
        iframe.setAttribute( "height", "34px" );
        iframe.setAttribute( "frameborder", "0" );
        iframe.setAttribute( "style", "position:relative; margin:0px 0px 0px 80px;" );
	ulElement.appendChild( iframe );

        var urlWk = location.href.substring(location.href.lastIndexOf("/")+1,location.href.length);
        var url = urlWk.split("#");
        if ( url[0] == "calendar.php" ) {
            //当ヘッドを後から作成する為、formのtargetが_blankにリセットされるので、ここでセット
            document.getElementById("saveDataForm").setAttribute("target", "msgFrame");
        }
}

function pageMove( href ) {
/*	
	if ( href == "userList.html" ) {
		if( !window.confirm('ユーザ一覧に戻りますか？') ) {
			return;
		}
	}
*/	
	location.href = href;
}

function frameAppear() {

    style = "position:relative; margin:0px 0px 0px 80px;";
    style += "-moz-border-radius:15px; -webkit-border-radius:15px; border-radius: 15px;";
    style += "-moz-box-shadow:0px 0px 10px #000000; -webkit-box-shadow: 0px 0px 10px #000000; box-shadow: 0px 0px 10px #000000;";

    var iframe = document.getElementById("msgFrame");
    iframe.setAttribute( "style", style );
    iframe.setAttribute( "class", "animated fadeInRightBig" );
    setTimeout( function(){
        iframe.setAttribute( "style", "position:relative; margin:0px 0px 0px 80px;" );
        iframe.setAttribute( "class", "" );
    }, 2000 );

}

function frameWarning() {

    style = "position:relative; margin:0px 0px 0px 80px;";
    style += "-moz-border-radius:15px; -webkit-border-radius:15px; border-radius: 15px;";
    style += "-moz-box-shadow:0px 0px 10px #000000; -webkit-box-shadow: 0px 0px 10px #000000; box-shadow: 0px 0px 10px #000000;";

    var iframe = document.getElementById("msgFrame");
    iframe.setAttribute( "style", style );
    iframe.setAttribute( "class", "animated bounceOut" );
    setTimeout( function(){
        iframe.setAttribute( "style", "position:relative; margin:0px 0px 0px 80px;" );
        iframe.setAttribute( "class", "" );
    }, 800 );

}
