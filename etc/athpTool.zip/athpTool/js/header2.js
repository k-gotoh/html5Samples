function headerTitileLi( hrefStr, text ) {
	var liElement = document.createElement( "li" );
	var aElement = document.createElement( "a" );
	aElement.setAttribute( "href", "#" );
	aElement.setAttribute( "onclick", "pageMove('" + hrefStr + "')" );
	aElement.innerHTML = text;
	liElement.appendChild( aElement );
	
	return liElement;
}

function createHeader() {
	
	
	var ulElement = document.getElementById( "nav" );
	
	ulElement.appendChild( headerTitileLi( "userList.html", "ユーザ一覧" ) );
		ulElement.appendChild( headerTitileLi( "#", "　　　　　　" ) );
	ulElement.appendChild( headerTitileLi( "basicSetting.html", "基本設定" ) );
	ulElement.appendChild( headerTitileLi( "urlSetting.html", "URL設定" ) );
	ulElement.appendChild( headerTitileLi( "engineSetting.html", "エンジン設定" ) );
	ulElement.appendChild( headerTitileLi( "excludeUrlSetting.html", "対象外URL設定" ) );
	
	var spanElement = document.createElement( "span" );
	spanElement.setAttribute( "class", "animated fadeIn" );
	var aElement = document.createElement( "a" );
	aElement.setAttribute( "href", "#" );
	aElement.setAttribute( "class", "a_demo_four" );
	aElement.setAttribute( "style", "position:relative;top:-14px;left:20px;font-size:14px;" );
	aElement.setAttribute( "onclick", "sendServer( 'dataSave.php' ,'msgFrame', true )" );
	aElement.innerHTML = "　登録　";
	spanElement.appendChild( aElement );
	ulElement.appendChild( spanElement );


    var iframe = document.createElement( "iframe" );
    iframe.setAttribute( "id", "msgFrame" );
    iframe.setAttribute( "name", "msgFrame" );
    iframe.setAttribute( "width", "300px" );
    iframe.setAttribute( "height", "34px" );
    iframe.setAttribute( "frameborder", "0" );
    iframe.setAttribute( "style", "position:relative; margin:0px 0px 0px 80px;" );
    ulElement.appendChild( iframe );

	var basic = getStorage( "basic" );
	
	
    var urlWk = location.href.substring(location.href.lastIndexOf("/")+1,location.href.length);
    var url = urlWk.split("#");
    
	var data = getStorage( "login" );    
    if ( url[0] == "dataGet.php" || url[0] == "basicSetting.html" ) {
			document.getElementById("loginId").value = data.id;
	        document.getElementById("loginEmail").value = data.email;
	        document.getElementById("recallUserId").value = localStorage.getItem( 'idKey' );
	        
			var division =  data.division;

		    var target = document.getElementById( "recallForm" );
			if ( division == "develope" &&  basic.status == "2" ) {
				
		        target.setAttribute( "style", "visibility:visible;" );
		        target.setAttribute( "class", " animated bounceInUp" );
			} else {
				target.setAttribute( "style", "visibility:hidden;" );
			}
	}


	
	//frameAppear();
	
}

function pageMove( href ) {
	
	if ( href == "userList.html" ) {
		if( !window.confirm('ユーザ一覧に戻りますか？') ) {
			return;
		}
	}
	
	location.href = href;
}
/*
function dataCheck() {
    var sendForm = document.createElement( 'form' );
    document.body.appendChild( sendForm );
    sendForm.setAttribute( 'action' , "./dataCheck.php",false );
    sendForm.setAttribute( 'method' , 'post' );
    sendForm.setAttribute( 'target' , 'msgFrame' );
    sendForm.submit();
}
*/
/**
*
* @param1 : arr 連想配列 key=パラメタ名 value=データ
* @param2 : action 渡すプログラム名
* @param3 : target (不要な場合はnull)
*/

function jsPost( arr, action, target ) {
    var sendForm = document.createElement( 'form' );
    document.body.appendChild( sendForm );

   for(var key in arr) {
     var input = document.createElement( 'input' );
     input.setAttribute( 'type' , 'hidden' );
     input.setAttribute( 'id' , key );
     input.setAttribute( 'name' , key );
     input.setAttribute( 'value' , arr[ key ] );
     sendForm.appendChild( input );
  }

  sendForm.setAttribute( 'id' , 'sendForm' );
  sendForm.setAttribute( 'name' , 'sendForm' );
  sendForm.setAttribute( 'action' , action );
  sendForm.setAttribute( 'method' , 'post' );
  if ( target != null ) {
    sendForm.setAttribute( 'target' , target );
  }
  
  sendForm.submit();

}

function sendServer(action, target, dataSend) {

  dataSave();
  var params = new Array();

  params[ 'idKey' ] = localStorage.getItem( 'idKey' );
  if ( dataSend ) {
      params[ 'basic' ] = localStorage.getItem( 'basic' );
      params[ 'urlList' ] = localStorage.getItem( 'urlList' );
      params[ 'excludeUrlList' ] = localStorage.getItem( 'excludeUrlList' );
      var eid = localStorage.getItem( 'selectedEID' );
      params[ 'selectedEID' ] = eid;


      var engineMaster = localStorage.getItem( "engineMaster");
      var engineList = engineMaster.split(",");

      for ( var i = 0; i < engineList.length; i++ ) {
          var chk = engineList[i].split(":");
          if ( chk[2] == "1" ) {
              params[ chk[0] ] = localStorage.getItem( chk[0] );
          }
      }




      var eidListParse = JSON.parse( eid );
      //eidListParse += "";
      var eidList = eidListParse[ 'selectedEID' ] .split( ',');
      if ( eidList.length != 0 ) {
          for ( var i = 0; i < eidList.length; i++ ) {
              var chk = eidList[ i ].split( ':' );
              var dicId = chk[ 0 ];
              if ( dicId != null && dicId != "" ) {
                  params[ dicId ] = localStorage.getItem( dicId );
              }
          }
      }

  }
  jsPost( params, action, target );

  frameAppear();
}

function frameAppear() {

    style = "position:relative; margin:0px 0px 0px 80px;";
    style += "-moz-border-radius:15px; -webkit-border-radius:15px; border-radius: 15px;";
    style += "-moz-box-shadow:0px 0px 10px #000000; -webkit-box-shadow: 0px 0px 10px #000000; box-shadow: 0px 0px 10px #000000;";

    var iframe = document.getElementById("msgFrame");
    iframe.setAttribute( "style", style );
    iframe.setAttribute( "class", "animated fadeInRightBig" );
    setTimeout( function(){
        iframe.setAttribute( "style", "position:relative; margin:0px 0px 0px 80px;" );
        iframe.setAttribute( "class", "" );
    }, 2000 );

}

function frameWarning() {

    style = "position:relative; margin:0px 0px 0px 80px;";
    style += "-moz-border-radius:15px; -webkit-border-radius:15px; border-radius: 15px;";
    style += "-moz-box-shadow:0px 0px 10px #000000; -webkit-box-shadow: 0px 0px 10px #000000; box-shadow: 0px 0px 10px #000000;";

    var iframe = document.getElementById("msgFrame");
    iframe.setAttribute( "style", style );
    iframe.setAttribute( "class", "animated bounceOut" );
    setTimeout( function(){
        iframe.setAttribute( "style", "position:relative; margin:0px 0px 0px 80px;" );
        iframe.setAttribute( "class", "" );
    }, 800 );

}

function loginCheck() {
	
	var loginCheck = sessionStorage.getItem( "status" );
	if ( !loginCheck ) {
		alert( "直接このページには入れません" );
		location.href = "./login.html";
	}
	
}

window.addEventListener("message", function(e){
  
  switch ( e.data.action ) {
	case "saved":
	    if ( e.data.history != "" ) {
			
			localStorage.setItem( "idKey", e.data.id );
	        var data = getStorage( "basic" );
	        data.status = "1";
	        setStorage( "basic", data );
	        
	        var hist = new Object;
	        hist.userHistory = e.data.history + "\t1\t";
	        setStorage( "userHistory", hist );
	        
            var urlWk = location.href.substring(location.href.lastIndexOf("/")+1,location.href.length);
			var url = urlWk.split("#");

		    if ( url[0] == "dataGet.php" || url[0] == "basicSetting.html" ) {
				    var target = document.getElementById( "sortable1" );
    				var li = document.createElement( "li" );
    				li.setAttribute( "class", "ui-state-default animated bounceInDown" );
    				li.innerHTML = e.data.history + " データ登録";
    				target.appendChild( li );
				
			}
	    }
  }

},false);
