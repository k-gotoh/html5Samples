/**
*
* @param1 : arr 連想配列 key=パラメタ名 value=データ
* @param2 : action 渡すプログラム名
* @param3 : target (不要な場合はnull)
*/

function jsPost( arr, action, target ) {
    var sendForm = document.createElement( 'form' );
    document.body.appendChild( sendForm );

   for(var key in arr) {
     var input = document.createElement( 'input' );
     input.setAttribute( 'type' , 'hidden' );
     input.setAttribute( 'id' , key );
     input.setAttribute( 'name' , key );
     input.setAttribute( 'value' , arr[ key ] );
     sendForm.appendChild( input );
  }

  sendForm.setAttribute( 'id' , 'form' );
  sendForm.setAttribute( 'name' , 'form' );
  sendForm.setAttribute( 'action' , action );
  sendForm.setAttribute( 'method' , 'post' );
  if ( target ) {
    sendForm.setAttribute( 'target' , target );
  }
  
  sendForm.submit();

}

function sendServer(action, target, dataSend) {

  var params = new Array();

  params[ 'idKey' ] = localStorage.getItem( 'idKey' );
  if ( dataSend ) {
      params[ 'basic' ] = localStorage.getItem( 'basic' );
      params[ 'urlList' ] = localStorage.getItem( 'urlList' );
      params[ 'excludeUrlList' ] = localStorage.getItem( 'excludeUrlList' );
      params[ 'selectedEID' ] = localStorage.getItem( 'selectedEID' );
  }
  jsPost( params, action, target );
}


