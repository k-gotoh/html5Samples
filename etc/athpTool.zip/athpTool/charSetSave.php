<?php

function msg( $msg ) {

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
</head>
<body>
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

}


include '../connect.php';

$db = "hptool";


$charSets = $_POST['charSetListSave'];




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  mysql_query( "begin", $connect );

  $charSetList   = explode( ',', $charSets );


  mysql_query( 'truncate table m_charset', $connect ) or die("trancateに失敗しました。");;

  for ( $i = 0; $i < count( $charSetList ); $i++ ) {

    $name = explode( ':', $charSetList[$i] );
    $sql  = "insert into m_charset value(";
    $sql .= "'"  . $name[0] . "'";
    $sql .= ",'" . $name[1] . "'";
    $sql .= ")";

    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
      print ( $sql );
      return;
    }
  }

  mysql_query( "commit", $connect );
  
  msg( "更新しました" );


  // MySQLへの接続を閉じる
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>