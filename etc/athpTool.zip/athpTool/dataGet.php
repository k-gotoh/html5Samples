<?php
/**
 * PHP5.4からでないと対応していないUnicodeアンエスケープをPHP5.3でもできるようにしたラッパー関数
 * @param mixed   $value
 * @param int     $options
 * @param boolean $unescapee_unicode
 */
function json_xencode($value, $options = 0, $unescapee_unicode = true)
{
  $v = json_encode($value);
  if ($unescapee_unicode) {
    $v = unicode_encode($v);
    // スラッシュのエスケープをアンエスケープする

    $v = preg_replace('/\\\\\//', '/', $v);
  }
  return $v;
}

/**
 * Unicodeエスケープされた文字列をUTF-8文字列に戻す。
 * 参考:http://d.hatena.ne.jp/iizukaw/20090422
 * @param unknown_type $str
 */
function unicode_encode($str)
{
  return preg_replace_callback("/\\\\u([0-9a-zA-Z]{4})/", "encode_callback", $str);
}

function encode_callback($matches) {
  return mb_convert_encoding(pack("H*", $matches[1]), "UTF-8", "UTF-16");
}

function getDicName( $connect, $eid ) {
    $array = array();
    $sql = "select dic_id, name, status from m_dic where eid = '" . $eid . "' order by status,seq";
    $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
    while ($row = mysql_fetch_assoc($result)) {

        $array[ $row[ 'dic_id' ] ] =  $row[ 'name' ] . "\t" . $row[ 'status' ];
    }

    return $array;

}

include '../connect.php';

$db = "hptool";


$id = $_POST[ 'selectedUserId' ];


// MySQLへ接続する
$connect = connect();

  // データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

/**
*
* ユーザ情報
*
*/

$basic = array();

if (  $id != 0  ) {

  $sql = "select * from m_user where user_id = " . $id . " order by plan_date desc, setting_id";
  $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
  $row = mysql_fetch_assoc($result);

  $basic['clienetName']   = $row['client_name'];
  $basic['clienetID']     = $row['client_id'];
  $basic['settingID']     = $row['setting_id'];
  $basic['planDate']      = $row['plan_date'];
  $basic['completeDate']  = $row['complete_date'];
  $basic['useCDN']        = $row['use_cdn'] == "1"  ? true : false;
  $basic['usePDF']        = $row['use_pdf'] == "1"  ? true : false;
  $basic['useCellular']   = $row['use_mobile'] == "1"  ? true : false;
  $basic['cancel']        = $row['cancel_flg']  == "1"  ? true : false;
  $basic['cancelDate']    = $row['cancel_date'];
  $basic['status']        = $row['status'];

} else {

  $basic['clienetName']   = "";
  $basic['clienetID']     = "";
   $basic['settingID']    = "";
  $basic['planDate']      = "";
  $basic['completeDate']  = "";
  $basic['useCDN']        = false;
  $basic['usePDF']        = false;
  $basic['useCellular']   = false;
  $basic['cancel']        = false;
  $basic['cancelDate']    = "";
  $basic['status']        = "1";
} 
$jsonBasic = json_xencode($basic);
//str_replace( '"', "'", $jsonBasic );


//url
$urlList = array();
$urlList[ 'urlFirst' ] = "";
$urlList[ 'cellularFirst' ] = false;
$urlList[ 'urlList' ] = "";
$urlList[ 'booleanList' ] = "";

$useUrlList = array();
$urls = array();
$booleans = array();

$sql = "select * from t_use_url where user_id = '" . $id . "' order by seq";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
   array_push( $urls, $row[ 'url' ] );
   array_push( $booleans, $row[ 'for_mobile' ] );
}


if ( count( $urls ) > 0 ) {
    $ret = array_splice( $urls,0 ,1 );
    $urlList[ 'urlFirst' ] = $ret[0] ;

    $ret = array_splice( $booleans,0 ,1 );
    $urlList[ 'cellularFirst' ] = $ret[0] == "1" ? true : false ;

    if ( count( $urls ) > 0 ) {
        $urlList[ 'urlList' ] = implode(",", $urls);
        $urlList[ 'booleanList' ] = implode(",", $booleans);
    }
}
$jsonUseUrl = json_xencode($urlList);


//対象外url
$excludeUrlList = array();
$excludeUrlList[ 'urlFirst' ] = "";
$excludeUrlList[ 'urlList' ] = "";

$unuseUrlList = array();

$sql = "select * from t_unuse_url where user_id = '" . $id . "' order by seq";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
   array_push( $unuseUrlList, $row[ 'url' ] );
}


if ( count( $unuseUrlList ) > 0 ) {
    $ret = array_splice( $unuseUrlList,0 ,1 );

    $excludeUrlList[ 'urlFirst' ] = $ret[0];

    if ( count( $unuseUrlList ) > 0 ) {

      $excludeUrlList[ 'urlList' ] = implode(",", $unuseUrlList);

    }
}
$jsonExcludeUrl = json_xencode( $excludeUrlList );



//エンジン
$selectedEIDList = array();
$selectedEIDList[ 'selectedEID' ] = "";
$engineList = array();

$sql = "select * from t_use_engine where user_id = '" . $id . "'";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {


    array_push( $engineList, $row[ 'eid' ] . ":1" );

}
if ( count( $engineList ) > 0 ) {
  $selectedEIDList[ 'selectedEID' ] = implode(",", $engineList);
}
$jsonSelectedEid = json_xencode($selectedEIDList);

/**
*
* エンジンマスタ
*
*/
$engineList = array();
$sql = "select * from m_engine order by seq";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
   array_push( $engineList, $row[ 'eid' ] . ":" .  $row[ 'name' ] .":" . $row[ 'force_flg' ]  );
}

$engineValue = implode(",", $engineList);



//辞書
$inputDic = "";


$dicMasterArray = array();
for ( $i = 0; $i < count( $engineList ) ; $i++ ){

    $useDicArray = array();
    $unuseDicArray = array();

    $chk = explode( ":", $engineList[ $i ] );
    $eid = $chk[0];

    $dicMasterArray = getDicName( $connect, $eid );


    $sql = "select * from t_use_dic where user_id = '" . $id . "' and eid = '" . $eid . "' order by eid,status,seq";

    $result2 = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
    while ($row = mysql_fetch_assoc($result2)) {

        $dicEid = $row[ 'dic_id' ];
        $dicStatus = $row[ 'status' ];

        $dicName = "";
        $strs = explode( "\t", isset( $dicMasterArray[ $dicEid ] ) ? $dicMasterArray[ $dicEid ] : "" );
        if ( count ( $strs ) > 0 ) {
            $dicName = $strs[0];
        }


        $add = $row[ 'dic_id' ] . "\t" . $dicName;

        if ( $dicStatus == "0" ) {
            if ( array_key_exists($eid, $useDicArray ) ) {
                $useDicArray[ $eid ] .= "," . $add;
            } else {
                $useDicArray[ $eid ]  = $add;
            }
        } else {
            if ( array_key_exists($eid, $unuseDicArray ) ) {
                $unuseDicArray[ $eid ] .= "," . $add;
            } else {
                $unuseDicArray[ $eid ]  = $add;
            }
        }

        unset( $dicMasterArray[ $row[ 'dic_id' ] ] );
    }

    if ( count( $dicMasterArray ) > 0 ) {
        foreach ($dicMasterArray as $key => $value) {
            
            $strs = explode( "\t", $value );
            $add = $key . "\t" . $strs[0];

            if ( $id == "0" && $strs[1] == "0" ) {
                if ( array_key_exists($eid, $useDicArray ) ) {
                    $useDicArray[ $eid ] .= "," . $add;
                } else {
                    $useDicArray[ $eid ]  = $add;
                }
            } else {
                if ( array_key_exists($eid, $unuseDicArray ) ) {
                    $unuseDicArray[ $eid ] .= "," . $add;
                } else {
                    $unuseDicArray[ $eid ]  = $add;
                }
            }



        }
    }



    foreach ($useDicArray as $key => $value) {
 
        $unuseRec = "";
        if ( array_key_exists($eid, $unuseDicArray ) ) {

            $unuseRec = $unuseDicArray[ $key ];
            unset( $unuseDicArray[ $key ] );
        }
        $valueRec = $useDicArray[ $key ] . ":" .  $unuseRec;
        $inputDic .= "<input id='" . $key . "' type='hidden' class='dic' value='" . $valueRec ."' />";
    }

    foreach ($unuseDicArray as $key => $value) {

        $valueRec = ":" . $unuseDicArray[ $key ];

        $inputDic .= "<input id='" . $key . "' type='hidden' class='dic' value='" . $valueRec ."' />";

    }



}


//履歴
$histArray = array();
$sql = "select * from t_user_history where user_id = " . $id . " order by insert_date";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {

    $date = $row[ 'insert_date' ];
    $status = $row[ 'status' ];
    $comment = $row[ 'comment' ];
    array_push( $histArray, $date . "\t" . $status  . "\t" . $comment );

}

$histList = array();
$histList[ 'userHistory' ] = "";

if ( count( $histArray ) > 0 ) {
  $histList[ 'userHistory' ] = implode(",", $histArray);
}
$jsonHistList = json_xencode($histList);




$html = <<< EOF
<!DOCTYPE html>
<html>
<title>@HP自動化ツール</title>
<link rel="shortcut icon" href="./favicon.ico"> 
<head>
<meta charset="UTF-8" />
<link rel="stylesheet" href="./css/header.css" />
<link rel="stylesheet" href="./css/title.css" type="text/css" />
<link rel="stylesheet" href="./css/button.css" type="text/css" />
<link rel="stylesheet" href="./css/roundedTextBox.css" type="text/css" />
<link rel="stylesheet" href="./css/captionText.css" type="text/css" />
<link rel="stylesheet" href="./css/uoul.css" type="text/css" />
<link rel="stylesheet" href="./css/checkBoxGroup.css" type="text/css" />
<link rel="stylesheet" href="./css/pageCurl.css" type="text/css" />
<link rel="stylesheet" href="./css/animate.css" />

<link rel="stylesheet" type="text/css" href="./css/style4.css" />


<style type="text/css">

</style>
<script src="./js/jquery-1.9.0.js"></script>

<script src="./js/jquery-ui-1.10.0.custom.min.js"></script>
<script src="./js/jquery.sortable.js"></script>

<script src="./js/jquery.min.js"></script>
<script src="./js/textualizer.js"></script>
<script src="./js/storage.js"></script>
<script src="./js/header2.js"></script>

<script language="javascript" type="text/javascript"/>


function titleEffect() {
    var list = [document.getElementById("headetTitleHidden").value]; // 目的のテキストを指定
    var txt = $('#headerTitle'); // id名を指定
    var options = {
        duration: 10,
        rearrangeDuration: 10,
        effect: 'slideLeft',
        centered: true
    }
 
    txt.textualizer(list, options);
    txt.textualizer('start');
}



$(function(){
	//チェックボックス
	$('div.check-group label').toggle(
		function () {
			$(this)
				.addClass('checked')
				.prev('input').attr('checked','checked');
		},
		function () {
			$(this)
				.removeClass('checked')
				.prev('input').removeAttr('checked');
		}
	);
});

/*
$(function() {
    $( '#sortable1' ) . sortable();
    $( '#sortable1' ) . disableSelection();
});
*/
editing = false;
function changeValue( obj ) {
  if (editing) {
    return;
  }
  editing = true;
  var elms = obj.childNodes;
  var innerText = obj.innerText;
  var inputTag = document.createElement('input');
  inputTag.setAttribute("size","90");
  inputTag.setAttribute("class","rounded animated fadeIn");
  inputTag.setAttribute("value",innerText == "　" ? "" : innerText);
  inputTag.setAttribute("onMouseOut","decideName(this)");
  inputTag.setAttribute("onblur","decideName(this)");

   obj.removeChild( obj.firstChild );

  var pos = null;
  if ( elms.length > 0 ) {
      pos = elms[0];
  }
  obj.insertBefore( inputTag, pos );

  inputTag.focus();
}

function decideName(obj) {
  if ( !editing ) {
    return;
  }
  editing = false;
  var text = obj.value;
  var liNode = obj.parentNode;
  liNode.removeChild( obj );

  var nextElement = null;
  var elms = liNode.childNodes;
  if ( elms.length > 0 ) {
      nextElement = elms[0];
  }
  
  liNode.innerText = text;
  if ( nextElement != null ) {
      liNode.appendChild( nextElement );
  }

}




function cancel(obj) {
  var clientName = document.getElementById("headerTitle"); 
  if (obj.checked ) {
     clientName.setAttribute("class","animated hinge pCurlDrop-shadow pCurlLifted");
  } else {
     clientName.setAttribute("class","pCurlDrop-shadow pCurlLifted");
  }
}

function inputedText() {
  document.getElementById("headerTitle").innerHTML = document.getElementById("clienetName").value + "(" + document.getElementById("planDate").value + ")";
}

STORAGE_KEY = "basic";

function dataSave() {

  var statusSave = getStorage("basic").status;
  var data = new Object;
  
  data.clienetID = document.getElementById("clienetID").value;
  data.clienetName = document.getElementById("clienetName").value;
  data.planDate = document.getElementById("planDate").value;
  data.cancel = document.getElementById("cancel").checked;
  data.settingID = document.getElementById("settingID").value;
  data.useCDN = document.getElementById("useCDN").checked;
  data.useCellular = document.getElementById("useCellular").checked;
  data.usePDF = document.getElementById("usePDF").checked;
  data.status = statusSave;
  
  setStorage( STORAGE_KEY, data );
}

function restoreData() {

   //var chk = document.getElementById("serverFlg").value;
  if ( document.getElementById("serverFlg").value == "1" ) {
    serverDataSave();
//    return;
  }

  createHeader();

  var data = getStorage( STORAGE_KEY );
/*
  if ( !data ) {
    return;
  }
*/


  document.getElementById("clienetID").value =  data.clienetID;
  document.getElementById("clienetName").value = data.clienetName;
  document.getElementById("headetTitleHidden").value = data.clienetName  + "(" + data.planDate + ")";
  document.getElementById("planDate").value = data.planDate;
  document.getElementById("cancel").checked = data.cancel;
  document.getElementById("settingID").value = data.settingID;
  
  if ( data.useCDN ) {
    document.getElementById("useCDN").setAttribute("checked","checked");
    document.getElementById("useCDNLabel").setAttribute("class","checked");
  }

  if ( data.useCellular ) {
    document.getElementById("useCellular").setAttribute("checked","checked");
    document.getElementById("useCellularLabel").setAttribute("class","checked");
  }

  if ( data.usePDF ) {
    document.getElementById("usePDF").setAttribute("checked","checked");
    document.getElementById("usePDFLabel").setAttribute("class","checked");
  }

  titleEffect();

  //url
  var useUrlData = getStorage( "urlList" );

  var useUrlList = document.getElementById("useUrlList");

  var useUrlLi = document.createElement("li"); 
  useUrlLi.setAttribute("class", "ui-state-default");
  useUrlLi.setAttribute("onclick", "changeValue(this)");
  useUrlLi.innerHTML = useUrlData.urlFirst != "" ? useUrlData.urlFirst : "　";

  if  ( useUrlData.cellularFirst ) {
      var useUrlMobile = document.createElement("img");
      useUrlMobile.setAttribute("src", "./images/mobile.png");
   //   useUrlMobile.setAttribute("style", "top:5px");
      useUrlLi.appendChild( useUrlMobile );
  }

  useUrlList.appendChild( useUrlLi );

  if  ( useUrlData.urlList != null && useUrlData.urlList != "" )  {
      var urls = useUrlData.urlList.split(",");
      var booleans = useUrlData.booleanList.split(",");

      for ( var i = 0; i < urls.length; i++ ) {

        var useUrlLi = document.createElement("li"); 
        useUrlLi.setAttribute("class", "ui-state-default");
        useUrlLi.setAttribute("onclick", "changeValue(this)");
        useUrlLi.innerHTML = urls[ i ]  !=  "" ? urls[ i ] : "　";

        if  ( booleans[ i ] == "1" ) {
          var useUrlMobile = document.createElement("img");
          useUrlMobile.setAttribute("src", "./images/mobile.png");
          useUrlLi.appendChild( useUrlMobile );
        }
        useUrlList.appendChild( useUrlLi );
     }
  }

//エンジン
  //エンジンマスタで無条件に使用
  var useEngineList = document.getElementById("useEngine");

  //var engineMaster = getStorage( "engineMaster" );
  var engineMaster = localStorage.getItem( "engineMaster" );
  var engineList = engineMaster.split(",");
  var engineNameList = new Array();

  var force = "【初期設定】　";
  for ( var i = 0; i < engineList.length; i++ ) {
    var chk = engineList[i].split(":");
    engineNameList[ chk[0] ] = chk[1];
    if ( chk[2] == "1" ) {
      force += chk[1]  + "　　　";
    }
  }
  if  ( force != "" ) {
      var engineLi = document.createElement("li"); 
      engineLi.setAttribute("class", "ui-state-default");
      engineLi.innerHTML = force;
      useEngineList.appendChild( engineLi );
  }

  //選択されたエンジン
  var selectedEngineList = getStorage( "selectedEID" );
  if  ( selectedEngineList.selectedEID != null && selectedEngineList.selectedEID != "" ) {
      var eidList = selectedEngineList.selectedEID.split(",");
      for ( var i = 0; i < eidList.length; i++ ) {
        var chk = eidList[i].split(":");
        if ( chk[1] == "1" ) {
            
            var engineLi = document.createElement("li"); 
            engineLi.setAttribute("class", "ui-state-default");
           // engineLi.setAttribute("onclick", "changeValue(this)");
            engineLi.innerHTML = engineNameList[ chk[0] ];
            useEngineList.appendChild( engineLi );
        }
      }
  }

//対象外url
    var excludeUrl = document.getElementById("excludeUrl");
    var excludeUrlList = getStorage( "excludeUrlList" );

    var excludeUrlLi = document.createElement("li"); 
    excludeUrlLi.setAttribute("class", "ui-state-default");
    excludeUrlLi.setAttribute("onclick", "changeValue(this)");
    excludeUrlLi.innerHTML = excludeUrlList.urlFirst != "" ? excludeUrlList.urlFirst : "　";
    excludeUrl.appendChild( excludeUrlLi );


//    if  ( excludeUrlList.urlList != null && excludeUrlList.urlList != "" ) {
        var excludeList = excludeUrlList.urlList.split(",");
        if ( excludeList.length > 0 && excludeList[0] != "" ) {
            for ( var i = 0; i < excludeList.length; i++ ) {
                var excludeUrlLi = document.createElement("li"); 
                excludeUrlLi.setAttribute("class", "ui-state-default");
                excludeUrlLi.setAttribute("onclick", "changeValue(this)");
                excludeUrlLi.innerHTML = excludeList[ i ] != "" ? excludeList[ i ] : "　";
                excludeUrl.appendChild( excludeUrlLi );
            }
        }
//    }


//履歴
var effectArray = new Array( "bounceInUp", "bounceInLeft", "bounceInDown", "rollIn" );
var target = document.getElementById( "sortable1" );
userHistoryList = new Array();
var userHistories = getStorage("userHistory").userHistory;
userHistoryList = userHistories.split( "," );
if ( userHistoryList.length > 0 && userHistoryList[ 0 ] != "" )
    for ( var i = 0; i < userHistoryList.length; i++ ) {
        var row = userHistoryList[i];
        var chk = row.split( "\t" );

        var status= "";
        switch ( chk[ 1 ] ) {
            case "1":
                status = "データ登録";
                break;

            case "2":
                status = "開発チェック";
                break;

            case "3":
                status = "チェック済み";
                break;

            case "4":
                status = "リリース済み";
                break;
        }

        var rec = chk[ 0 ] + " "+ status;
        if ( chk[ 2 ] != null && chk[ 2 ] != "" ) {
            rec += "<br /><span style='font-size:11px'>" + chk[ 2 ] + "</span>";
        }

        var effect = " animated " + effectArray[ i % 4 ]
        var li = document.createElement( "li" );
        li.setAttribute( "class", "ui-state-default" + effect  );
        li.innerHTML = rec;
        target.appendChild( li );
    }


}

function serverDataSave() {

  //localStorage.clear();

  var id = document.getElementById("idKey").value;
  var serverBasic = document.getElementById("serverBasic").value;
  var serverUrl = document.getElementById("serverUrl").value;
  var serverEngine = document.getElementById("serverEngine").value;
  var serverDic = document.getElementById("serverDic").value;
  var serverCharSet = document.getElementById("serverCharSet").value;
  var serverExcludeUrl = document.getElementById("serverExcludeUrl").value;
  var userHistory = document.getElementById("userHistory").value;

  var engineMaster = document.getElementById("engineMaster").value;
  var dicMaster = document.getElementById("dicMaster").value;
  var charSetMaster = document.getElementById("charSetMaster").value;
  var tantoshaMaster = document.getElementById("tantoshaMaster").value;



  var dicList = document.getElementsByClassName("dic");
  for ( var i = 0; i < dicList.length; i++ ) {

      var data = new Object;

      var eid    = dicList[ i ].id;
      var dicValue = dicList[ i ].value;

      var rec = dicValue.split( ":" );

      data.useDic      = rec[0];
      data.nonUseDic  = rec[1];

      //localStorage.setItem( eid, data );
      setStorage( eid, data );

  }

  localStorage.setItem( "basic", serverBasic ); 
  localStorage.setItem( "urlList", serverUrl );
  localStorage.setItem( "excludeUrlList", serverExcludeUrl );
  localStorage.setItem( "selectedEID", serverEngine ); 
  localStorage.setItem( "userHistory", userHistory ); 

  localStorage.setItem( "engineMaster", engineMaster );

  setStorage(  "idKey", id );
}

function pageForward( obj, url ) {
  obj.parentNode.parentNode.setAttribute( "class", "animated lightSpeedOut" );
//  document.getElementById( ul ).setAttribute( "class", "rounded-list animated fadeOutRightBig"  );

  setTimeout( function() {
      location.href = url;
  },400);

}

function recall() {
    window.recallForm.submit();
}

function setHistory( date) {
    var target = document.getElementById( "sortable1" );
    var li = document.createElement( "li" );
    li.setAttribute( "class", "ui-state-default animated bounceInDown" );
    li.innerHTML = date + " データ登録<br/ >(差し戻し)" + document.getElementById("comment").value;
    target.appendChild( li );
    
    
    
    var data = getStorage( "basic" );
    data.status = "1";
    setStorage( "basic", data );
    
    setTimeout( function() {
        li.setAttribute( "class", "ui-state-default" );
        document.getElementById("recallForm").setAttribute( "class", "animated bounceOutDown" );
    }, 800 );
}
window.addEventListener("message", function(e){

    switch ( e.data.action ) {
        case "recalled":
              frameAppear();
              setHistory( e.data.date );
              break;
    }

  }, false);
</script>
</head>
<body onLoad="restoreData()" onBeforeUnload="return dataSave()">
<ul id='nav'></ul>


<table border="0"><tr><td width="350px">
<p class="title"> 基本設定</p></td>
<td width="900px" align="center"><p id="headerTitle" class="pCurlDrop-shadow pCurlLifted">クロスランゲージ市役所(2013/02/15)</p>
<!--iframe id="msgFrame" name="msgFrame" width="300px" height="40px" frameborder="0"></iframe-->
</td>
</tr></table>

<table border="0"><tr><td style="vertical-align: top;">
<table><tr><td>

</td></tr></table>
<table border="0">
<tr>
<td valign="center" width="200px">
<span class="caption">クライアント名</span>
</td>
<td valign="center">
<input id="clienetName" class="rounded" type="text" size="100" onkeyup="inputedText()"/>
</td>
</tr>

<tr>
<td valign="center">
<span class="caption">クライアントID</span>
</td>
<td valign="center">
<input id="clienetID" class="rounded" type="text" size="5" />
　<span class="caption">リリース予定日</span>
<input type="date" id="planDate" class="rounded" onChange="inputedText()">

　　　　<span class="caption"><label for="cancel">解約</labe></span><input type="checkbox" class="rounded" id="cancel" onClick="return cancel(this)"/>
</td>
</tr>

<tr>
<td valign="center">
<span class="caption">設定ID</span>
</td>
<td valign="center">
<input id="settingID" class="rounded" type="text" size="12" />
</td>
</tr>


<tr>
<td valign="center">
<span class="caption">使用の有無</span>
</td>
<td valign="center">

<div class="check-group clearfix">
	<div>
		<input id="useCDN" type="checkbox" name="check[]" value="c1" />
		<label id="useCDNLabel" for="useCDN">　CDN　</label>
	</div>
	<div>
		<input id="useCellular" type="checkbox" name="check[]" value="c2" />
		<label id="useCellularLabel" for="useCellular">　携帯　</label>
	</div>
	<div>
		<input id="usePDF" type="checkbox" name="check[]" value="c3" />
		<label id="usePDFLabel" for="usePDF">　PDF　</label>
	</div>
</div>
</td>
</tr>


<tr>
<td valign="top">
<br />
<span class="caption">対象url　</span>
<a href="#" class="button play" onclick="pageForward(this, './urlSetting.html')">設定</a>
</td>
<td valign="center">

<ol class="rounded-list" id="useUrlList"  >
</ol>

</td>
</tr>



<tr>
<td valign="top">
<br /> 
<span class="caption">エンジン </span>
<a href="#" class="button play" onclick="pageForward(this, './engineSetting.html')">設定</a>
</td>
<td valign="center">

<ol class="rounded-list" id="useEngine">
</ol>
</td>
</tr>




<!--tr>
<td valign="top">
<span class="caption">charset</span>
<a href="charSetSetting.html" class="button play"  onClick="return lineAdd()">設定</a>
</td>
<td valign="center">
<ol class="rounded-list"  >
<li class="ui-state-default">UTF-8</li>
<li class="ui-state-default">http://xxxxxxxxx SHIFT_JIS</li>
</ol>

</td>
</tr-->



<tr>
<td valign="top">
<br />
<span class="caption">対象外url</span>
<a href="#" class="button play"  onclick="pageForward(this, 'excludeUrlSetting.html')">設定</a>
</td>
<td valign="center">

<ol class="rounded-list" id="excludeUrl">
</ol>

</td>
</tr>
</table>

</td>
<td valign="top" style="padding:10px 0px 0px 50px; ">

<span class="caption">リリース履歴</span>
<ol id="sortable1" class="rectangle-list">
</ol>


<div id="recall" style="visibility:collapse">
<form id="recallForm" name="recallForm" action="./recall.php" method="post" target="msgFrame" >
差し戻しの理由<a href="#" class="button spark"  onclick="recall()">送信</a><br>
<textarea cols="62" rows="10"  id="comment" name="comment">
</textarea>
<input type="hidden" id="recallUserId" name="recallUserId" />
<input type="hidden" id="loginId" name="loginId" />
<input type="hidden" id="loginEmail" name="loginEmail" />
</form>
</div>


</td>
</tr>
</table>

<input type="hidden" id="serverFlg" value='1' />  <!--  value='1' -->
<input type="hidden" id="serverBasic" value='$jsonBasic' /> <!--  value='$jsonBasic' -->
<input type="hidden" id="serverUrl" value='$jsonUseUrl' /> <!-- value=''  -->
<input type="hidden" id="serverEngine" value='$jsonSelectedEid'/> <!-- value=''  -->
<input type="hidden" id="serverCharSet" /> <!-- value=''  -->
<input type="hidden" id="serverExcludeUrl" value='$jsonExcludeUrl' /> <!-- value=''  -->
<input type="hidden" id="serverDic" /> <!--  value='' -->

<input type="hidden" id="engineMaster" value='$engineValue' /> <!-- value='$engineValue'  -->
<input type="hidden" id="dicMaster"/> <!-- value=''  -->
<input type="hidden" id="charSetMaster" /> <!-- value=''  -->
<input type="hidden" id="tantoshaMaster" /> <!-- value=''  -->
<input type="hidden" id="idKey" value='$id' /> <!-- value='$id'  -->
<input type="hidden" id="userHistory" value='$jsonHistList' />

$inputDic

<input id="headetTitleHidden" type="hidden" value="クロスランゲージ区役所(2013/02/15)" />


</form>
</body>
</html>
EOF;


echo $html;

// MySQLへの接続を閉じる
mysql_close($connect) or die("MySQL切断に失敗しました。");



?>