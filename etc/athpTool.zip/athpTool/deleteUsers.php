<?php

function msg( $msg ) {

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
</head>
<body>
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

}

function deleteTable( $connect, $table, $userId ) {

  $sql = "delete from " . $table . " where user_id = '" . $userId . "'";
  mysql_query( $sql, $connect ) or die( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );

}



include '../connect.php';

$db = "hptool";


$userIds = $_POST[ 'userIds' ];
$userIdList = explode(",", $userIds);

$tableList = array( "t_user_history", "t_unuse_url", "t_use_url", "t_use_engine", "t_use_dic", "m_user");

// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  mysql_query( "begin", $connect );

$msg = "";

for ( $user = 0;$user < count( $userIdList ); $user++ ) {
    for ( $table = 0; $table < count( $tableList ); $table++ ) {

        deleteTable( $connect, $tableList[ $table ], $userIdList[ $user] );
        //$msg .= "userId=" . $userIdList[ $user ] . "'s " . $tableList[ $table ] . " deleted<br>";

    }
}


mysql_query( "commit", $connect );
$msg .= "削除が正常終了しました";   

msg( $msg );


  // MySQLへの接続を閉じる
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>