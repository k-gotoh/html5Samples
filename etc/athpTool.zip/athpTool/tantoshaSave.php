<?php

function msg( $msg ) {

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
</head>
<body>
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

}


include '../connect.php';

$db = "hptool";


$tantoshaNo = $_POST['tantoshaNoSave'];
$tantosha = $_POST['tantoshaSave'];
$depart = $_POST['departSave'];
$email = $_POST['emailSave'];
$depart = $_POST['departSave'];
$pass = $_POST['passSave'];

// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  mysql_query( "begin", $connect );

  $tantoshaNoList = explode( ',', $tantoshaNo );
  $tantoshaList =  explode( ',', $tantosha );
  $departList =  explode( ',', $depart );
  $emailList =  explode( ',', $email );
  $passList =  explode( ',', $pass );

  mysql_query( 'truncate table m_tantosha', $connect ) or die("trancateに失敗しました。");;

  for ( $i = 0; $i < count( $tantoshaNoList ); $i++ ) {
    $sql  = "insert into m_tantosha value(";
    $sql .= " '" . $tantoshaNoList[$i] . "'";
    $sql .= ",'" . $tantoshaList[$i] . "'";
    $sql .= ",'" . $departList[$i] . "'";
    $sql .= ",'" . $emailList[$i] . "'";
    $sql .= ",'" . $passList[$i] . "'";
    $sql .= ")";

    $result = mysql_query( $sql, $connect );
    if ( !$result ) {
      print ( $sql );
      return;
    }
  }

  mysql_query( "commit", $connect );
  msg( "更新しました" );


  // MySQLへの接続を閉じる
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>