<?php


include '../connect.php';

$db = "hptool";




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  $tantoshaNoList = array();
  $tantoshaList =  array();
  $departList =  array();
  $emailList =  array();
  $passList =  array();

  $sql = "SELECT * FROM m_tantosha";
  $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
  while ($row = mysql_fetch_assoc($result)) {
    array_push( $tantoshaNoList, $row[ 'id' ] );
    array_push( $tantoshaList, $row[ 'name' ] );
    array_push( $departList, $row[ 'division' ] );
    array_push( $emailList, $row[ 'email' ] );
    array_push( $passList, $row[ 'password' ] );
  }


  if ( count( $tantoshaNoList ) == 0 ) {
    $tantoshaNoList[0] = "";
    $tantoshaList[0] = "";
    $departList[0] = "sales";
    $emailList[0] = "";
    $passList[0] = "";
  }


$data = "";
for ( $i = 1; $i < count($tantoshaNoList); $i++ ) {
  $num = str_pad( $i + 1 ,2 ,"0", STR_PAD_LEFT);
  
  $selectedArray = array();
  $selectedArray[ 'sales' ] = "";
  $selectedArray[ 'develope' ] = "";
  $dev =  $departList[ $i ];
  
 $selectedArray[ $departList[$i] ] = "selected";

  $data .= <<< DATA_EOF
             <div>
	     <span>$num</span>
	     <input type="text" class="rounded tantoshaNo" size="5" placeholder="担当者番号" value="$tantoshaNoList[$i] " required="">
	      <input type="text" class="rounded tantosha" size="30" onblur="savetantosha()" placeholder="担当者名を入力" value="$tantoshaList[$i]" required="">
	　<span class="caption">部署</span>
	    <select class="rounded depart" >
	    <option value="sales" $selectedArray[$dev] >営業</option>
	    <option value="develope" $selectedArray[$dev] >開発</option>
	    </select>
	         <span class="caption">email</span>
	    <input type="text" class="rounded eMail" size="80" placeholder="メールアドレスを入力" value="$emailList[$i]" required="">
            <input type='text' class='rounded pass' size='10' placeholder='pass' value="$passList[$i]"required />

	    <a href="#" class="button delete" onclick="return lineDel(this)">削除</a>
            </div>
DATA_EOF;

}




$html = <<< EOF
<!DOCTYPE html>
<html lang="ja" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>@HP自動化ツール</title>
<link rel="shortcut icon" href="./favicon.ico"> 
<meta charset="UTF-8" />

<link rel="stylesheet" href="./css/header.css" />
<link rel="stylesheet" href="./css/captionText.css" type="text/css" />
<link rel="stylesheet" href="./css/roundedTextBox.css" type="text/css" />
<!--link rel="stylesheet" href="./css/pageCtantosha.css" type="text/css" /-->
<link rel="stylesheet" type="text/css" href="./css/style4.css" />

<style type="text/css">
span.error {
   color: red;
  }
 
div.error {
   color: red;
    -webkit-animation-name: 'rotate';
	-webkit-animation-duration: 1s;
	-webkit-animation-timing-function: ease;
}


div.shadow{
  color:#fff;
  padding:10px;
  background:#ffc0cb;
  -webkit-transition: 0.5s ease-in-out;
  -moz-box-shadow: 10px 3px 15px #800000;
  -webkit-box-shadow: 10px 3px 15px #800000;
}

  @-webkit-keyframes 'rotate' {
    0% { -webkit-transform: rotate(0deg); }
    33% { -webkit-transform: rotate(0.5deg); }
    66% { -webkit-transform: rotate(-0.5deg); }
    100% { -webkit-transform: rotate(0deg); }
  }
}





</style>
<link rel="stylesheet" href="./css/button.css" type="text/css" />
<link rel="stylesheet" href="./css/title.css" type="text/css" />
<link rel="stylesheet" href="./css/animate.css" />

<script type="text/javascript" src="./js/common.js"></script>
<script type="text/javascript" src="./js/settingHeader2.js"></script>
<script type="text/javascript" src="./js/jquery-1.9.0.js"></script>
<script type="text/javascript" src="./js/beforeUnload.js"></script>

<script language="javascript" type="text/javascript">

    var insertHtml = "<span></span>" + 
"     <input type='text' class='rounded tantoshaNo' size='5' placeholder='担当者番号' required /> " +
"     <input type='text' class='rounded tantosha' size='30' onBlur='savetantosha()' placeholder='担当者名を入力' required />　" +
"    <span class='caption'>部署</span>" +
"    <select class='rounded depart'>" +
"    <option value='sales' selected>営業</option>" +
"    <option value='develope'>開発</option>" +
"    </select>     " +
"    <span class='caption'>email</span>" +
"    <input type='text' class='rounded eMail' size='80' placeholder='メールアドレスを入力' required />" +
"    <input type='text' class='rounded pass' size='10' placeholder='pass' required />" +
"    <a href='#' class='button delete'  onClick='return lineDel(this)'>削除</a>";

    currentSelect = "";

    function lineAdd() {
      var target = document.getElementById("lineLast");
      var newElement = document.createElement("div"); 
      newElement.setAttribute("name","changeMe");
      newElement.innerHTML = insertHtml;
      target.insertBefore(newElement, null);
      savetantosha();
      var changeTarget = document.getElementsByName("changeMe").item(0);
      changeTarget.setAttribute("name","");
      changeTarget.setAttribute("class","animated bounceIn");
      //renumber();
    }


    function lineDel(obj) {
      var parentObj = obj.parentNode;
      parentObj.setAttribute("class","animated bounceOut");
      setTimeout( function(){  
           parentObj.setAttribute("class","");
           parentObj.parentNode.removeChild(obj.parentNode);
           savetantosha();
      }, 500 );


      //renumber();

    }


    function renumber(errNumberList)  {
      var i = 1;
      //var tantoshaList = document.getElementById("lineLast");
      var tantoshaNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(tantoshaNode) {
        i++;
        tantoshaNode.getElementsByTagName('span').item(0).innerHTML = toZeroPadding(i, 2);
        if (errNumberList.join().match(i)) {
           tantoshaNode.getElementsByTagName('span').item(0).setAttribute("class","error");
           tantoshaNode.setAttribute("class","error");
        } else {
           tantoshaNode.getElementsByTagName('span').item(0).setAttribute("class","");
           tantoshaNode.setAttribute("class","");
        }


        tantoshaNode = tantoshaNode.nextElementSibling;
      }
    }

/*   */
    function dataPost() {
      var tantoshaNoList = new Array();
      var tantoshaList = new Array();
      var departList = new Array();
      var emailList = new Array();  
      var passList = new Array();

      tantoshaList.push( document.getElementById("tantoshaFirst").value  );
      tantoshaNoList.push( document.getElementById("tantoshaNoFirst").value  );
      departList.push( document.getElementById("departFirst").value  );
      emailList.push( document.getElementById("eMailFirst").value  );
      passList.push( document.getElementById("passFirst").value  );


      var tantoshaNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(tantoshaNode) {
        tantoshaNoList.push( tantoshaNode.getElementsByClassName('tantoshaNo').item(0).value );
        tantoshaList.push( tantoshaNode.getElementsByClassName('tantosha').item(0).value );
        departList.push( tantoshaNode.getElementsByClassName('depart').item(0).value );
        emailList.push( tantoshaNode.getElementsByClassName('eMail').item(0).value );
        passList.push( tantoshaNode.getElementsByClassName('pass').item(0).value );
   
        tantoshaNode = tantoshaNode.nextElementSibling;
      }
      document.getElementById("tantoshaNoSave").value = tantoshaNoList.join();
      document.getElementById("tantoshaSave").value = tantoshaList.join();
      document.getElementById("departSave").value = departList.join();
      document.getElementById("emailSave").value = emailList.join();
      document.getElementById("passSave").value = passList.join();    

      document.frm.submit();

      frameAppear(); 

    }



    function savetantosha() {
      var tantoshaNo = new Array();
      var tantoshaList = new Array();

      var errNumberList = new Array();
      var i = 1;

      var inputText = document.getElementById("tantoshaFirst").value;
      if (inputText) {
          tantoshaList.push(inputText);
      } else {
          errNumberList.push(i);
      }

      var tantoshaNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(tantoshaNode) {
        var tantoshaInputNodes = tantoshaNode.getElementsByTagName('input');
        
        
        var textValue = tantoshaInputNodes.item(0).value.replace(/(^\s+)|(\s+$)/g, ""); //trim
        if (textValue) {
            i++;
            if (!tantoshaList.join().match(textValue)) { 
              tantoshaList.push(textValue);
            } else {
              errNumberList.push(i);
            }
         
        }
   
        tantoshaNode = tantoshaNode.nextElementSibling;
      }

      document.getElementById("tantoshaSave").value = tantoshaList.join();
      renumber(errNumberList);

    }


    function gettantoshaText() {
       alert(document.getElementById("tantoshaSave").value);

    }

    function showDetail(obj) {
       var tantoshatext = obj.parentNode.getElementsByTagName('input').item(0).value;

       if (currentSelect) {
          currentSelect.setAttribute("class","");
       }
       currentSelect = obj.parentNode;
       currentSelect.setAttribute("class","shadow");

    }


function frmSubmit(){
    document.frm.submit();
}

function execute() {
  document.frm.submit();
}

function init() {
  createHeader();
}
 </script>
</head>
<body onload="init()">
<ul id='nav'></ul>

<table border="0"><tr><td width="350px">
<p class="title"> 担当者登録</p></td>
</tr></table>


<form id="frm" name="frm" action="./tantoshaSave.php" method="POST" target="msgFrame">


  <div>
  <a href="#" class="button add"  onClick="return lineAdd()">行追加</a>

  <!--input class="button play" type="submit" value="保存"/><br /><br /-->
  </div>
  <div>
    <span>01</span>
    <input type="text" class="rounded" name="tantoshaNoFirst" id="tantoshaNoFirst" size='5' placeholder='担当者番号' value="$tantoshaNoList[0]"equired />
    <input type="text" class="rounded" name="tantoshaFirst" id="tantoshaFirst" size='30' placeholder='担当者名を入力' value="$tantoshaList[0]" required />　
    <span class="caption">部署</span>
    <select name="departFirst"  id="departFirst" class="rounded" value="$departList[0]">
    <option value="sales" selected>営業</option>
    <option value="develope">開発</option>
    </select>     
    <span class="caption">email</span>
    <input type="text" class="rounded" name="eMailFirst" id="eMailFirst" size='80' placeholder='メールアドレスを入力' value="$emailList[0]" required />
    <input type='text' class='rounded'  name="passFirst" id="passFirst"  size='10' placeholder='pass' value="$passList[0]" required />
  </div>

  <div id="lineLast">$data</div>

  <input type="hidden" name="tantoshaNoSave" id="tantoshaNoSave"><br/>
  <input type="hidden" name="tantoshaSave" id="tantoshaSave"><br/>
  <input type="hidden" name="departSave" id="departSave"><br/>
  <input type="hidden" name="emailSave" id="emailSave"><br/>
  <input type="hidden" name="passSave" id="passSave"><br/>

</form>
</body>
</html>
EOF;


echo $html;

  //結果保持用メモリを開放する
  mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>