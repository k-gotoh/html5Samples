<?php


include '../connect.php';

$db = "hptool";


$selectedEid = $_POST['selectedEid'];




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  $eidList = array();
  $statusList =  array();
  $seqList =  array();
  $idList =  array();
  $nameList =  array();

  $sql = "SELECT * FROM m_dic where eid='" . $selectedEid . "' order by eid,status,seq";
  $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
  while ($row = mysql_fetch_assoc($result)) {
    array_push( $eidList, $row[ 'eid' ] );
    array_push( $statusList, $row[ 'status' ] );
    array_push( $seqList, $row[ 'seq' ] );
    array_push( $idList, $row[ 'dic_id' ] );
    array_push( $nameList, $row[ 'name' ] );

  }



$data = array("","","");
for ( $i = 0; $i < count($eidList); $i++ ) {
  $data[ $statusList[$i] ] .= "<li class='ui-state-default' id='" . $idList[$i] . "' ";
  $data[ $statusList[$i] ] .= "ondragstart='f_dragstart(event)' onClick='changeName(this)'>" . $idList[$i] . ":" . $nameList[$i] . "</li>";

}




$html = <<< EOF
<!DOCTYPE html
<html>
<head>
<meta charset="UTF-8" />

<link rel="stylesheet" href="./css/uoul.css">
<link rel="stylesheet" href="./css/title.css" type="text/css" />
<link rel="stylesheet" href="./css/button.css" type="text/css" />
<link rel="stylesheet" href="./css/captionText.css" type="text/css" />
<link rel="stylesheet" href="./css/animate.css" />
<link rel="stylesheet" href="./css/dialog.css" />
<link rel="stylesheet" href="./css/trashStyle.css" type="text/css" />
<link rel="stylesheet" href="./css/roundedTextBox.css" type="text/css" />
<style type="text/css">

td {padding: 2px 2px 2px 50px;}

span.radialBtn {
		/* prefix */
		-moz-border-radius: 40px;
		-webkit-border-radius: 40px;
		background-image: -moz-linear-gradient(-90deg,rgba(255,255,255,0.9),rgba(255,255,255,0));
		background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0,rgba(255,255,255,0.9)), color-stop(1,rgba(255,255,255,0)));
		text-shadow: 1px 1px 0 rgba(255,255,255,0.6);
		-webkit-transition: background-color, .5s;
		-webkit-box-shadow: 1px 1px 4px rgba(0,0,0,0.6);
		-moz-box-shadow: 1px 1px 4px rgba(0,0,0,0.6);

		color: #333;
		display: block;
		text-decoration: none;
		text-align: center;
		line-height: 40px;
		width: 40px;
		height: 40px;
	}
span.radialBtn:hover {
	background-color: orange;
	color: #333;
}

span.btn5 {
	background-color: #44c0fe;
	border: solid 1px #777;
}


nol.nonSelected {
    counter-reset:li; /* Initiate a counter */
    padding:0; /* Remove the default left padding */
    list-style:none; /* Disable the normal item numbering */
}
ol.nonSelected li {
    position:relative; /* Create a positioning context */
    margin:0 0 3px 1em; /* Give each list item a left margin to make room for the numbers */
    padding:3px 1px;
    border-top:2px solid #666;
    background:#f6f6f6;
}
ol.nonSelected li:before {
    content:counter(li); /* Use the counter as content */
    counter-increment:li; /* Increment the counter by 1 */
    /* Position and style the number */
    position:absolute;
    top:-2px;
    left:-2em;
    width:2em;
    padding:4px 0;
    border-top:2px solid #666;
    color:#fff;
    background:#666;
    font-weight:bold;
    font-family:"Helvetica Neue", Arial, sans-serif;
    text-align:center;
}

div#dropbox {
 width:142px;
 height:110px;
 -khtml-user-drag: element;
}

#dialog{
  color:#fff;
  -moz-box-shadow: 10px 3px 15px #888888;
  -webkit-box-shadow: 10px 3px 15px #888888;
background:#fcfcfc;

}

.fire {
font-weight: 500;
text-shadow: 0 0 4px #ccc, 0 -5px 4px #ff3, 2px -10px 6px #fd3, -2px -15px 11px #f80, 2px -18px 18px #f20;

}


</style>


<script src="./js/jquery-1.9.0.js"></script>
<script src="./js/jquery-ui-1.10.0.custom.min.js"></script>
<script src="./js/jquery.sortable.js"></script>
<script type="text/javascript" src="./js/beforeUnload.js"></script>


<script>


$(function() {
    $( '#sortable1' ) . sortable();
    $( '#sortable1' ) . disableSelection();
});

$(function() {
    $( '#sortable2' ) . sortable();
    $( '#sortable2' ) . disableSelection();
});

$(function() {
    $( '#sortable3' ) . sortable();
    $( '#sortable3' ) . disableSelection();
});


$(function() {

	$('#sortable1, #sortable2, #sortable3').sortable({
		connectWith: '.connected'
	});
 
        $('#sortable1').sortable('disable');
	$('#sortable1').sortable({
		items: ':not(.disabled)'
	});

        $('#sortable2').sortable('disable');
	$('#sortable2').sortable({
		items: ':not(.disabled)'
	});


        $('#sortable3').sortable('disable');
	$('#sortable3').sortable({
		items: ':not(.disabled)'
	});
});




function save() {

  var selectedDicList = new Array();
  var dicList = document.getElementById("sortable1").getElementsByTagName("li");
  
  for ( i = 0; i < dicList.length; i++ ) {
    selectedDicList.push( dicList.item(i).innerText );

  }
  window.parent.postMessage(selectedDicList.join(),"*");

}


function lineAdd() {

  var dicID = document.getElementById("addDicId").value.replace(/(^\s+)|(\s+$)/g, "");
  var dicName = document.getElementById("addDicName").value.replace(/(^\s+)|(\s+$)/g, "");
  if ( dicID == "" || dicName == "" ) {
   alert("入力されていません。");
   return
  }
  document.getElementById("addDicId").value =  "";
  document.getElementById("addDicName").value  = "";



  var loObj = document.getElementById("sortable1");
  var element = document.createElement('li');
  element.setAttribute( "class","ui-state-default animated FadeInUp" );
  element.setAttribute( "id", dicID );
  element.setAttribute( "ondragstart", "f_dragstart(event)" );
  element.setAttribute( "onClick", "changeName(this)" );
  element.setAttribute( "draggable", "true" );

  element.innerHTML = dicID + ":" + dicName;
  loObj.appendChild(element); 

   $( '#sortable1' ) . sortable();
   $( '#sortable1' ) . disableSelection();
   $('#sortable1').sortable('disable');
   $('#sortable1').sortable({
		items: ':not(.disabled)'
   });

   $('#sortable1, #sortable2, #sortable3').sortable({
		connectWith: '.connected'
   });

  setTimeout(function(){
    element.setAttribute("class","ui-state-default");
  },500);
 
  changeStatus();

}


//************* ゴミ箱処理 *************


imgTrashEmpty      = "./images/trashEmpty.png";
imgTrashFull       = "./images/trashFull.png";
imgTrashEmptyHover = "./images/trashHover.png";      //hover用
imgTrashFullHover  = "./images/trashFullHover.png";  //hover用

soundIndex = 0;


function f_dragstart(event){
  //ドラッグするデータのid名をDataTransferオブジェクトにセット
  event.dataTransfer.setData("liIdSave", event.target.id);
}

/***** ドラッグ要素がドロップ要素に重なっている間の処理 *****/
function dragoverOnTrash(event){
  var trashCnt = document.getElementById("divTrash").getElementsByTagName("li").length;
  if ( trashCnt == 0 ) {
    document.getElementById("trashImage").src = imgTrashEmptyHover ;
    document.getElementById("trashCnt").innerHTML = "";
    document.getElementById("trashCnt").style.padding = "0px";

  } else {
    document.getElementById("trashImage").src = imgTrashFullHover;
    document.getElementById("trashCnt").innerHTML = trashCnt;
    document.getElementById("trashCnt").style.padding = "3px";
  }
  //dragoverイベントをキャンセルして、ドロップ先の要素がドロップを受け付けるようにする
 
  event.preventDefault();
}

/***** ドロップ時の処理 *****/
function dropIntoTrash(event){

  document.getElementById("intoTrash").play();

  //ドラッグされたデータのid名をDataTransferオブジェクトから取得
  var id_name = event.dataTransfer.getData("liIdSave");
  //id名からドラッグされた要素を取得
  var drag_elm =document.getElementById(id_name);
  
//  var loObj = drag_elm.parentNode;
 // loObj.removeChild(drag_elm);

  drag_elm.setAttribute("onClick","recover(this)");

  //ドロップ先にドラッグされた要素を追加
  document.getElementById("divTrash").appendChild(drag_elm);
  //event.currentTarget.appendChild(drag_elm);
  //エラー回避のため、ドロップ処理の最後にdropイベントをキャンセルしておく
  event.preventDefault();
  document.getElementById("trashImage").src = imgTrashFull;
  var trashCnt = document.getElementById("divTrash").getElementsByTagName("li").length;
  document.getElementById("trashCnt").innerHTML = trashCnt;
  document.getElementById("trashCnt").style.padding = "3px";

  document.getElementById("aaa").play();

  changeStatus();

}

function leaveFromTrash() {
  var trashCnt = document.getElementById("divTrash").getElementsByTagName("li").length;
  if ( trashCnt == 0 ) {
    document.getElementById("trashImage").src = imgTrashEmpty
    document.getElementById("trashCnt").innerHTML = "";
    document.getElementById("trashCnt").style.padding = "0px";
  } else {
    document.getElementById("trashImage").src = imgTrashFull;
    document.getElementById("trashCnt").innerHTML = trashCnt;
    document.getElementById("trashCnt").style.padding = "3px";
  }
}


function recover(obj) {

  document.getElementById("outOfTrash" + soundIndex ).play();
  soundIndex++;
  if ( soundIndex > 4) {
    soundIndex = 0;
  }

  var loObj = document.getElementById("sortable3");
  obj.parentNode.removeChild(obj);
  obj.setAttribute("onClick","");
  obj.setAttribute("class","ui-state-default animated FadeInUp");
  loObj.appendChild(obj); 
   $('#sortable3').sortable();
   $('#sortable3').disableSelection();
   $('#sortable3').sortable('disable');
   $('#sortable3').sortable({
	items: ':not(.disabled)'
   });

  var liCnt = document.getElementById("divTrash").getElementsByTagName("li").length;
  if ( liCnt == 0 ) {
    document.getElementById("trashImage").src = imgTrashEmpty;
    $( "#dialog" ).dialog( "close" );
    document.getElementById("trashCnt").innerHTML = "";
    document.getElementById("trashCnt").style.padding = "0px";
  } else {
    var trashCnt = document.getElementById("divTrash").getElementsByTagName("li").length;
    document.getElementById("trashCnt").innerHTML = trashCnt;
    document.getElementById("trashCnt").style.padding = "3px";
  }
  setTimeout(function(){
    obj.setAttribute("class","ui-state-default");
  },500);

  changeStatus();
}





  $(function() {
    $( "#dialog" ).dialog({
      autoOpen: false,
      show: {
        effect: "explode",
        duration: 1000
      },
      hide: {
        effect: "explode",
        duration: 1000
      }
    });
 
    $( "#opener" ).click(function() {
      $( "#dialog" ).dialog( "open" );
    });
  });



editing = false;
function changeName(obj) {

  if (editing) {
    return;
  }
  editing = true;
  var elm = obj.innerHTML;
  var inputTag = document.createElement('input');
  inputTag.setAttribute("type","text");
  inputTag.setAttribute("size","22");
  inputTag.setAttribute("class","rounded animated fadeIn");
  inputTag.setAttribute("value",elm);
  inputTag.setAttribute("onMouseOut","decideName(this)");
  inputTag.setAttribute("onblur","decideName(this)");
  obj.innerHTML = "";
  obj.appendChild(inputTag);
  inputTag.focus();

  changeStatus();

}

function decideName(obj) {
  if ( !editing ) {
    return;
  }
  editing = false;
  var name = obj.value.split(":");
  var liNode = obj.parentNode;
  liNode.removeChild( obj );
  liNode.id = name[1];
  liNode.title = name[1];
  liNode.innerHTML = obj.value;


}

function postData() {

  var useDicList = new Array();
  var useDicNode = document.getElementById("sortable1").getElementsByTagName('li').item(0);
  while(useDicNode) {
    useDicList.push( useDicNode.innerHTML );
    useDicNode = useDicNode.nextElementSibling;
  }
  document.getElementById("useDic").value = useDicList.join();


  var visibleDicList = new Array();
  var visibleDicNode = document.getElementById("sortable2").getElementsByTagName('li').item(0);
  while(visibleDicNode) {
    visibleDicList.push( visibleDicNode.innerHTML );
    visibleDicNode = visibleDicNode.nextElementSibling;
  }
  document.getElementById("visibleDic").value = visibleDicList.join();



  var invisibleDicList = new Array();
  var invisibleDicNode = document.getElementById("sortable3").getElementsByTagName('li').item(0);
  while(invisibleDicNode) {
    invisibleDicList.push( invisibleDicNode.innerHTML );
    invisibleDicNode = invisibleDicNode.nextElementSibling;
  }
  document.getElementById("invisibleDic").value = invisibleDicList.join();

  document.frm.submit();

}

isChanged = false;

function changeStatus() {
    
  if ( isChanged ) {
      return;
  }
  
  window.parent.postMessage( "statusChanged", "*" );
  isChanged = true;

}

window.addEventListener("message", function(e){
    postData();
}, false );

</script>
</head>
<body>
<br />
　　　　　　　<a href="#" class="button play"  onClick="postData()">保存</a>

<br />
<table border="0" >

<tr><td width="500px" valign="top">

<ol id="sortable1" class="rectangle-list">
使用
$data[0]
</ol>
<span class="caption">追加</span><input type="text" size="12" id="addDicId"  placeholder='辞書IDを入力' class='rounded'/>
<input type="text" size="22" id="addDicName"  placeholder='辞書名を入力' class='rounded'/>
<a href="#" class="button add"  onClick="return lineAdd()">追加</a><br />
<div id="dropbox" onDragOver="dragoverOnTrash(event)" onDrop="dropIntoTrash(event)" onDragLeave="leaveFromTrash()">
<br /><br /><br /><br /><br />
<img src="./images/trashEmpty.png" id="trashImage" onClick=" $( '#dialog' ).dialog( 'open' );"/>
<span id="trashCnt" class="caption rounded" style="font-size:0.5em;float:left;background-color:#ff3333;color:#fff;padding:0px;"></span>
</div>
</td>
<td valign="top" width="200px" >
<ol id="sortable2" class="rounded-list">
未使用
$data[1]
</ol>

</td>


<td valign="top"  width="200px">

<div style="padding:1px 1px;"></div>
<ol id="sortable3" class="nonSelected">
非表示
$data[2]
</ol>





</td>
</tr></table>


<div id="dialog" title="　　ゴミ箱">
<ol id="divTrash" class="rounded-list fire"> <!-- rounded-list -->

</ol>
</div>

<form name="frm" action="./dicSave.php" method="POST" target="msgFrame">
  <input type="hidden" name="eid" id="eid" value="$selectedEid">
  <input type="hidden" name="useDic" id="useDic">
  <input type="hidden" name="visibleDic" id="visibleDic">
  <input type="hidden" name="invisibleDic" id="invisibleDic">
</form>

<!-- Sound Effect -->
<!-- ゴミ箱へ入れる -->
<audio id="intoTrash" preload="auto">
<source src="./SE/a05.mp3" type="audio/mp3"/>
<source src="./SE/a05.ogg" type="audio/ogg"/>
<source src="./SE/a05.wav" type="audio/wav"/>
</audio>

<!-- ゴミ箱から取り出す -->
<audio id="outOfTrash0" preload="auto">
<source src="./SE/a08.mp3" type="audio/mp3"/>
<source src="./SE/a08.ogg" type="audio/ogg"/>
<source src="./SE/a08.wav" type="audio/wav"/>
</audio>
<audio id="outOfTrash1" preload="auto">
<source src="./SE/a08.mp3" type="audio/mp3"/>
<source src="./SE/a08.ogg" type="audio/ogg"/>
<source src="./SE/a08.wav" type="audio/wav"/>
</audio>
<audio id="outOfTrash2" preload="auto">
<source src="./SE/a08.mp3" type="audio/mp3"/>
<source src="./SE/a08.ogg" type="audio/ogg"/>
<source src="./SE/a08.wav" type="audio/wav"/>
</audio>
<audio id="outOfTrash3" preload="auto">
<source src="./SE/a08.mp3" type="audio/mp3"/>
<source src="./SE/a08.ogg" type="audio/ogg"/>
<source src="./SE/a08.wav" type="audio/wav"/>
</audio>
<audio id="outOfTrash4" preload="auto">
<source src="./SE/a08.mp3" type="audio/mp3"/>
<source src="./SE/a08.ogg" type="audio/ogg"/>
<source src="./SE/a08.wav" type="audio/wav"/>
</audio>

</body>
</html>
EOF;

echo $html;

  //結果保持用メモリを開放する
  mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>