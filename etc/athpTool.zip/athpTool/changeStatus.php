<?php

function deleteTable( $connect, $table, $userId ) {

  $sql = "delete from " . $table . " where user_id = '" . $userId . "'";
  mysql_query( $sql, $connect ) or die( "削除に失敗しました" .  mysql_errno($connect).": ".mysql_error($connect) );

}


function deleteUsers( $connect, $userIdList ) {

    $tableList = array("t_unuse_url", "t_use_url", "t_use_engine", "t_use_dic", "m_user");
    mysql_query( "begin", $connect );
    
    for ( $user = 0;$user < count( $userIdList ); $user++ ) {
        for ( $table = 0; $table < count( $tableList ); $table++ ) {

            deleteTable( $connect, $tableList[ $table ], $userIdList[ $user] );
        }
    }
}


function setStatus( $connect, $action, $userIds ) {

    $sql = "update m_user set status = '" .$action . "' where user_id in (" . $userIds . ")";
    mysql_query( $sql, $connect ) or die("更新に失敗しました。");
    
    $now = date( "Y-m-d H:i:s" );
    $userList = explode( ",", $userIds );
    for ( $i = 0; $i < count( $userList ); $i++ ) {
        $sql = "insert into t_user_history value(" . $userList[ $i ] . ", '" . $now . "','" . $action  . "', '')";
        mysql_query( $sql, $connect ) or die("追加に失敗しました。" . $sql);
    }
}

function sendMail( $connect, $action ) {

   
   
   $toArray = array();
   $sql = "select name,email from m_tantosha";
   $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
   while ($row = mysql_fetch_assoc($result)) {
       array_push( $toArray, $row[ 'name'] . "<" . $row[ 'email' ] . ">");
   }
   $to = implode( ",", $toArray );
   

   

   
   $from = "muroi <muroi@crosslanguage.co.jp>";
   
   
   
   $array = array();

   $cnt = 0;
   $sql = "select client_name, setting_id, plan_date from m_user";
   $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
   while ($row = mysql_fetch_assoc($result)) {
   
       $cnt++;
       $userInfo = $cnt . ". " . $row[ 'client_name' ] . "  " .  $row[ 'plan_date' ] . " " .  $row[ 'setting_id' ];

       array_push( $array, $userInfo );
   
   }
   $userList = implode( "\n", $array );
   
   $subject = "";
   switch ( $action ) {
       case "requestCheck":
           $subject = "【@hp】チェック依頼(" . $cnt . "件)";
           break;
        
       case "checkCompleted":
           $subject = "【@hp】チェック完了(" . $cnt . "件)";
           break;
             
       case "released":
           $subject = "【@hp】リリースしました(" . $cnt . "件)";
           break;
   }
   
      
   
   
   $file = "./mailData/" . $action . ".txt";
   ob_start();
   readfile($file);
   $data = ob_get_contents();
   ob_end_clean();
   
   $body = str_replace('$userList', $userList, $data);
   
   
   $toEnc =  mb_convert_encoding($to, "UTF-8", "auto");
   $subjectEnc =  mb_convert_encoding($subject, "UTF-8", "auto");
   $bodyEnc =  mb_convert_encoding($body, "UTF-8", "auto");
   $fromEnc = mb_convert_encoding($from, "UTF-8", "auto");
   
   //mb_send_mail($toEnc,$subjectEnc,$bodyEnc,"From:".$fromEnc);
   
      

}




    
    

include '../connect.php';

$db = "hptool";

$userIds = $_POST[ 'userIds' ];
$action = $_POST[ 'action' ];


// MySQLへ接続する
$connect = connect();

// データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

mysql_query( "begin", $connect );

$msg = "";
$userIdList = explode(",", $userIds);
switch ( $action ) {
    case "createFile":
        
        break;
    
    case "requestCheck":
        setStatus( $connect, 2, $userIds );
        sendMail ( $connect, $action );
        $msg = "チェック依頼をしました";
        break;
        
    case "checkCompleted":
        setStatus( $connect, 3, $userIds );
        sendMail ( $connect, $action );
        $msg = "完了処理をしました";
        break;
             
    case "released":
        setStatus( $connect, 4, $userIds );
        sendMail ( $connect, $action );
        $msg = "リリース済にしました";
        break;
         
    case "delete":
        deleteUsers( $connect, $userIdList );
        break;
}




$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
<script>
function sendParent() {

    var data = new Object;
    data.action = "refind";
    window.parent.postMessage( data ,"*");
}
</script>
</head>
<body onload="sendParent()">
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

mysql_query( "commit", $connect );
//結果保持用メモリを開放する
//mysql_free_result($result);
mysql_close($connect) or die("MySQL切断に失敗しました。");
?>