<?php


include '../connect.php';

$db = "hptool";




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  $eidList = array();
  $nameList =  array();
  $forceList =  array();

  $sql = "SELECT * FROM m_engine";
  $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
  while ($row = mysql_fetch_assoc($result)) {
    array_push( $eidList, $row[ 'eid' ] );
    array_push( $nameList, $row[ 'name' ] );
    array_push( $forceList, $row[ 'force_flg' ] );

  }


  if ( count( $eidList ) == 0 ) {
    return;
  }





$data = "";
for ( $i = 0; $i < count($eidList); $i++ ) {

  $data .= <<< DATA_EOF
    <li><label><input type="radio" name="langtype" value="$eidList[$i]" />$nameList[$i]</label></li>
DATA_EOF;

}



$checked  = ( $forceList[0] == "1" )?"checked":"";

$html = <<< EOF
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />

<link rel="stylesheet" href="./css/uoul.css">
<link rel="stylesheet" href="./css/title.css" type="text/css" />
<link rel="stylesheet" href="./css/button.css" type="text/css" />
<link rel="stylesheet" href="./css/header.css" />
<link rel="stylesheet" href="./css/animate.css" />
<link rel="stylesheet" type="text/css" href="./css/style4.css" />

<style type="text/css">
.langtype-list {
	padding:0;
}

	.langtype-list li {
		display:inline;
		list-style-type:none;
	}

	.langtype-list label {
		display:inline-block;
		font-family:Verdana, Geneva, Arial, Helvetica, sans-serif;
		font-size:0.8em;
		padding:0.3em 1em;
		background-color:#ddd;
		color:#999;
		border:2px solid #bbb;
		border-radius:20px;
		text-shadow:1px 1px 1px #fff;
		box-shadow:inset 1px 1px 5px #fff;
		cursor:pointer;
	}

	.langtype-list label:hover {
		border-color:#69a;
		color:#69a;
	}

	.langtype-list label.selected {
		color:#fff;
		background-color:#37a;
		box-shadow: inset 0px 0px 10px #036;
		border-color:#036;
		text-shadow:-1px -1px 1px #036;
	}

	.langtype-list label input {
		display:none;
	}


iframe#dicFrame {-moz-border-radius: 25px;
-webkit-border-radius: 25px;
border-radius: 25px;
/*IE 7 AND 8 DO NOT SUPPORT BORDER RADIUS*/
-moz-box-shadow: 0px 0px 20px #000000;
-webkit-box-shadow: 0px 0px 20px #000000;
box-shadow: 0px 0px 20px #000000;
/*IE 7 AND 8 DO NOT SUPPORT BLUR PROPERTY OF SHADOWS*/
}


</style>


<script src="./js/jquery.min.js"></script>
<script type="text/javascript" src="./js/settingHeader2.js"></script>

<script>
isLoaded = false;
function init() {
  createHeader();
  isLoaded = true;

}

function dataPost() {
    isChanged = false
    window.dicFrame.postMessage( "postData" , "*" );

    frameAppear();

}

</script>
</head>
<body onload="init()">
<ul id='nav'></ul>
<table border="0"><tr><td width="350px">
<p class="title"> 辞書登録</p></td>
</tr></table>
<br />
<form class="question">

<ul class="langtype-list">
$data
</ul>

</form>
<script>
/**
 * As jQuery plugin
 */
(function(){

	// return;

	$.fn.extend({
		toggleButtons : function(callback){
			var radios = this;
			radios.on("change", function(e){
				radios.closest("label").removeClass("selected");
				$(e.target).closest("label").addClass("selected");
				callback.call(this, e);
			});
			radios.closest("label").on("click", function(e){
				var input = $(this).find("input");
				if(! input.prop("checked")){
					input.prop("checked", true).trigger("change");
				}
			});
			radios.filter(":first").trigger("change");
		}
	});

	$("input[name=langtype]").toggleButtons(function(){
		console.log(this);
		console.log(arguments);
	});

}());


$("input[name=langtype]").toggleButtons(function(e){
        if ( !isLoaded ) {
            return;
        }
     // 選択変更時に何かする

 if ( isChanged ) {
    if ( !confirm("データが変更されている可能性がありますが、ページを移動しますか？") ) {
        return;
    }
    isChanged = false;
 }
 console.log("Changed to " + e.target.value);
 document.getElementById("selectedEid").value = e.target.value;
 document.dicSub.submit();
});


isChanged = false;
window.addEventListener("message", function(e){

  switch ( e.data ) {
    case "statusChanged":
        isChanged = true;
        break;

  }

}, false);

</script>
<br />
<br />
<br />
<form id="dicSub" name="dicSub" action="./dicSub.php" method="post" target="dicFrame">
<input type="hidden" name="selectedEid"  id="selectedEid" />
</form>
<iframe src="./blank.html" id="dicFrame"  name="dicFrame"  frameborder="0" width="1200px" height="500px" />
</body>
</html>

EOF;


echo $html;

  //結果保持用メモリを開放する
  mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>