<?php
   
    

include '../connect.php';

$db = "hptool";

$userId = $_POST[ 'recallUserId' ];
$comment = $_POST[ 'comment' ];
$loginId = $_POST[ 'loginId' ];
$loginEmail = $_POST[ 'loginEmail' ];


// MySQLへ接続する
$connect = connect();
// データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

mysql_query( "begin", $connect );

$msg = "";

//*****

$sql = "select client_name from m_user where user_id = " . $userId;
$userName = "";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
    $userName = $row[ 'client_name' ];
}


$toArray = array();
$sql = "select name,email from m_tantosha";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
   array_push( $toArray, $row[ 'name'] . "<" . $row[ 'email' ] . ">");
}
$to = implode( ",", $toArray );

$subject = "【@hp】差し戻しされました";



$from = $loginEmail;




$file = "./mailData/recall.txt";
ob_start();
readfile($file);
$body = ob_get_contents();
ob_end_clean();

$body = str_replace('$userList', $userName, $body);
$body = str_replace('$comment',  $comment, $body);

$toEnc =  mb_convert_encoding($to, "UTF-8", "auto");
$subjectEnc =  mb_convert_encoding($subject, "UTF-8", "auto");
$bodyEnc =  mb_convert_encoding($body, "UTF-8", "auto");
$fromEnc = mb_convert_encoding($from, "UTF-8", "auto");
//mb_send_mail($toEnc,$subjectEnc,$bodyEnc,"From:".$fromEnc);


//******
$sql = "update m_user set status = '1' where user_id = " . $userId . "";
mysql_query( $sql, $connect ) or die("更新に失敗しました。");
    
$now = date( "Y-m-d H:i:s" );

$sql = "insert into t_user_history value(" . $userId . ", '" . $now . "','1', ' (差し戻し)" . $comment . "')";
mysql_query( $sql, $connect ) or die("追加に失敗しました。" . $sql);

$msg = "差し戻しました";

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
<script>
function sendParent() {
    var data = new Object;
    data.action = "recalled";
    data.date = '$now';
    window.parent.postMessage( data ,"*");
}
</script>
</head>
<body onload="sendParent()">
<span>$msg</span>
</body>
</html>
EOF;

echo $html;

mysql_query( "commit", $connect );
//結果保持用メモリを開放する
//mysql_free_result($result);
mysql_close($connect) or die("MySQL切断に失敗しました。");
?>