<?php
/**
 * PHP5.4からでないと対応していないUnicodeアンエスケープをPHP5.3でもできるようにしたラッパー関数
 * @param mixed   $value
 * @param int     $options
 * @param boolean $unescapee_unicode
 */
function json_xencode($value, $options = 0, $unescapee_unicode = true)
{
  $v = json_encode($value);
  if ($unescapee_unicode) {
    $v = unicode_encode($v);
    // スラッシュのエスケープをアンエスケープする

    $v = preg_replace('/\\\\\//', '/', $v);
  }
  return $v;
}

/**
 * Unicodeエスケープされた文字列をUTF-8文字列に戻す。
 * 参考:http://d.hatena.ne.jp/iizukaw/20090422
 * @param unknown_type $str
 */
function unicode_encode($str)
{
  return preg_replace_callback("/\\\\u([0-9a-zA-Z]{4})/", "encode_callback", $str);
}

function encode_callback($matches) {
  return mb_convert_encoding(pack("H*", $matches[1]), "UTF-8", "UTF-16");
}


$param = $_POST['para'];


$ans = json_decode($param,true);
print($ans['clienetName']);

$arr = array();
$arr['a'] = 'aaaa';
$arr['b'] = 'びびび';

$json = json_xencode($arr);



print($json);

$html = <<< EOF
<!DOCTYPE html>
<html>
<head></head>
<script>
function jsonRead(){
  var aaa = document.getElementById("test").value;
  var data = JSON.parse( aaa );
  document.getElementById("a").value = data.a;
  document.getElementById("b").value = data.b;
}
</script>
<body onLoad="jsonRead()">
<input type="hidden" id="test" value='$json' />
<input type="text" id="a" value="" />
<input type="text" id="b" value="" />
</body>
</html>
EOF;

print $html;




?>