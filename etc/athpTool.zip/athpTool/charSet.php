<?php


include '../connect.php';

$db = "hptool";




// MySQLへ接続する
  $connect = connect();

  // データベースを選択する
  $sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

  $charSetList = array();
  $defaultList = array();

  $sql = "SELECT * FROM m_charset";
  $result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
  while ($row = mysql_fetch_assoc($result)) {
    array_push( $charSetList, $row[ 'charset' ] );
    array_push( $defaultList, $row[ 'default_display' ] );
  }


  if ( count( $charSetList ) == 0 ) {
    $charSetList[0] = "";
    $defaultList[0] = "1";
  }


$data = "";
for ( $i = 1; $i < count($charSetList); $i++ ) {
  $num = str_pad( $i + 1 ,2 ,"0", STR_PAD_LEFT);
  $checked = ( $defaultList[$i] == "1" )?"checked":"";
  $data .= <<< DATA_EOF
  <div>
    <span>$num</span><input type='text' class='rounded charSet' size='30' onBlur='savecharSet()' placeholder='charSetを入力' value='$charSetList[$i]'required />
<span class='caption'>初期表示</span><input type='checkbox' class='rounded default' onClick='defaultSet(this)' $checked/>
    <a href='#' class='button delete'  onClick='return lineDel(this)'>削除</a>
  </div>
DATA_EOF;

}



$checked  = ( $defaultList[0] == "1" )?"checked":"";

$html = <<< EOF
<!DOCTYPE html>
<html lang="ja" xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>@HP自動化ツール</title>
<link rel="shortcut icon" href="./favicon.ico"> 
<meta charset="UTF-8" />

<link rel="stylesheet" href="./css/header.css" />
<link rel="stylesheet" href="./css/captionText.css" type="text/css" />
<link rel="stylesheet" href="./css/roundedTextBox.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="./css/style4.css" />

<style type="text/css">
span.error {
   color: red;
  }
 
div.error {
   color: red;
    -webkit-animation-name: 'rotate';
	-webkit-animation-duration: 1s;
	-webkit-animation-timing-function: ease;
}


div.shadow{
  color:#fff;
  padding:10px;
  background:#ffc0cb;
  -webkit-transition: 0.5s ease-in-out;
  -moz-box-shadow: 10px 3px 15px #800000;
  -webkit-box-shadow: 10px 3px 15px #800000;
}

  @-webkit-keyframes 'rotate' {
    0% { -webkit-transform: rotate(0deg); }
    33% { -webkit-transform: rotate(0.5deg); }
    66% { -webkit-transform: rotate(-0.5deg); }
    100% { -webkit-transform: rotate(0deg); }
  }
}





</style>
<link rel="stylesheet" href="./css/button.css" type="text/css" />
<link rel="stylesheet" href="./css/title.css" type="text/css" />
<link rel="stylesheet" href="./css/animate.css" />

<script src="./js/common.js"></script>
<script type="text/javascript" src="./js/settingHeader2.js"></script>

<script language="javascript" type="text/javascript">

    var insertHtml = "<span>01</span><input type='text' class='rounded charSet' size='30' onBlur='savecharSet()' placeholder='charSetを入力' required />" +
" <span class='caption'>初期表示</span><input type='checkbox' class='rounded default' onClick='defaultSet(this)'/>" +
"    <a href='#' class='button delete'  onClick='return lineDel(this)'>削除</a>";

    currentSelect = "";

    function lineAdd() {
      var target = document.getElementById("lineLast");
      var newElement = document.createElement("div"); 
      newElement.setAttribute("name","changeMe");
      newElement.innerHTML = insertHtml;
      target.insertBefore(newElement, null);
      savecharSet();
      var changeTarget = document.getElementsByName("changeMe").item(0);
      changeTarget.setAttribute("name","");
      changeTarget.setAttribute("class","animated rotateIn");
      //renumber();
    }


    function lineDel(obj) {
      var parentObj = obj.parentNode;
      parentObj.setAttribute("class","animated rotateOut");
      setTimeout( function(){  
           parentObj.setAttribute("class","");
           parentObj.parentNode.removeChild(obj.parentNode);
           savecharSet();
      }, 500 );


      //renumber();

    }


    function renumber(errNumberList)  {
      var i = 1;
      //var charSetList = document.getElementById("lineLast");
      var charSetNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(charSetNode) {
        i++;
        charSetNode.getElementsByTagName('span').item(0).innerHTML = toZeroPadding(i, 2);
        if (errNumberList.join().match(i)) {
           charSetNode.getElementsByTagName('span').item(0).setAttribute("class","error");
           charSetNode.setAttribute("class","error");
        } else {
           charSetNode.getElementsByTagName('span').item(0).setAttribute("class","");
           charSetNode.setAttribute("class","");
        }


        charSetNode = charSetNode.nextElementSibling;
      }
    }

    function savecharSet() {
      var charSetList = new Array();
      var errNumberList = new Array();
      var i = 1;

      var inputText = document.getElementById("charSetFirst").value;
      if (inputText) {
          charSetList.push(inputText);
      } else {
          errNumberList.push(i);
      }

      var charSetNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
      while(charSetNode) {
        var charSetInputNodes = charSetNode.getElementsByTagName('input');
        
        
        var textValue = charSetInputNodes.item(0).value.replace(/(^\s+)|(\s+$)/g, ""); //trim
        if (textValue) {
            i++;
            if (!charSetList.join().match(textValue)) { 
              charSetList.push(textValue);
            } else {
              errNumberList.push(i);
            }
         
        }
   
        charSetNode = charSetNode.nextElementSibling;
      }

      document.getElementById("charSetSave").value = charSetList.join();
      renumber(errNumberList);

    }


    function getcharSetText() {
       alert(document.getElementById("charSetSave").value);

    }

    function showDetail(obj) {
       var charSettext = obj.parentNode.getElementsByTagName('input').item(0).value;

       if (currentSelect) {
          currentSelect.setAttribute("class","");
       }
       currentSelect = obj.parentNode;
       currentSelect.setAttribute("class","shadow");

    }


function frmSubmit(){
    document.frm.submit();
}


function defaultSet( obj ) {

  var firstCbx = document.getElementById("defaultFirst");
  if ( obj == firstCbx ) {
    firstCbx.checked = true;
  } else {
    firstCbx.checked = false;
  }

  var divNode = document.getElementById("lineLast").getElementsByTagName("div").item(0);
  while(divNode) {
    var cbxNode = divNode.getElementsByClassName('default').item(0);
    if ( obj == cbxNode ) {
      cbxNode.checked = true;
    } else {
      cbxNode.checked = false;
    }

    divNode = divNode.nextElementSibling;
  }

}

function postData() {
  var charSetList = new Array();
  var str = document.getElementById("charSetFirst").value;
  str += ":" + ( document.getElementById("defaultFirst").checked?"1":"0" );
  charSetList.push( str );

  var divNode = document.getElementById("lineLast").getElementsByTagName('div').item(0);
  while(divNode) {
    var str =  divNode.getElementsByClassName('charSet').item(0).value;
    str += ":" + ( divNode.getElementsByClassName('default').item(0).checked?"1":"0" );
    charSetList.push( str );

    divNode = divNode.nextElementSibling;
  }
  document.getElementById("charSetListSave").value = charSetList.join();
  document.frm.submit();

}


function init() {
  createHeader();
}
 </script>
</head>
<body onLoad="init()">
<ul id='nav'></ul>

<table border="0"><tr><td width="350px">
<p class="title"> 文字コード登録</p></td>
</tr></table>


<form name="frm" id="frm" action="./charSetSave.php" method="POST" target="msgFrame">


  <div>
  <a href="#" class="button add"  onClick="return lineAdd()">追加</a>
  <a href="#" class="button play"  onClick="postData()">保存</a>
  <iframe name="msgFrame" width="300px" height="40px" frameborder="0"></iframe>
  <!--input class="button play" type="submit" value="保存"/><br /><br /-->
  </div>
  <div>
    <span>01</span><input type="text" class="rounded" id="charSetFirst" size='30' onBlur='savecharSet()' placeholder='charSetを入力' value='$charSetList[0]' required />
    <span class="caption">初期表示</span><input type="checkbox" id="defaultFirst" class="rounded"onClick="defaultSet(this)" $checked/>
  </div>

  <div id="lineLast">$data</div>

  <input type="hidden" id="charSetSave">
  <input type="hidden" name="charSetListSave" id="charSetListSave">

</form>
</body>
</html>
EOF;


echo $html;

  //結果保持用メモリを開放する
  mysql_free_result($result);
  mysql_close($connect) or die("MySQL切断に失敗しました。");
?>