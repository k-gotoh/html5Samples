<?php


include '../connect.php';

$db = "hptool";

$userId = $_POST[ 'userId' ];
$pass = $_POST[ 'password' ];



// MySQLへ接続する
  $connect = connect();

// データベースを選択する
$sdb = mysql_select_db($db,$connect) or die("データベースの選択に失敗しました。");

$msg = "login failed";
$chk = "NG";

$id = "";
$name = "";
$div = "";
$email = "";

$sql = "select * from m_tantosha where id = '" . $userId . "'";
$result = mysql_query($sql, $connect) or die("クエリの送信に失敗しました。<br />SQL:".$sql);
while ($row = mysql_fetch_assoc($result)) {
    if ( $pass == $row[ 'password' ] ) {
        $chk = "OK";
        $id = $row[ 'id' ];
        $name = $row[ 'name' ];
        $div  = $row[ 'division' ];
        $email = $row[ 'email' ];
        
    }
}

if ( $chk == "OK" ) {
  $msg  = "login ". $name . "さん";

}



$html = <<< EOF
<!DOCTYPE html>
<html lang="ja">
<head>
<style>
span { font-size:12px;color:red; }
</style>
<script>
function sendParent() {

    var data = new Object;
    data.id = '$id'
    data.email = '$email'
    data.respnse = '$chk';
    data.name = '$name'
    data.division = '$div';
    window.parent.postMessage( data ,"*");
}
</script>
</head>
<body onload="sendParent()">
<span>$msg</span>
</body>
</html>
EOF;

echo $html;


//結果保持用メモリを開放する
//mysql_free_result($result);
mysql_close($connect) or die("MySQL切断に失敗しました。");
?>