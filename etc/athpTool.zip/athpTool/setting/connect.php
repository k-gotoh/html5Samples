<?php

function connect () {

  $url = "localhost";
  $user = "root";
  $pass = "gotoh0819";

  // MySQLへ接続する
  $link = mysql_connect($url,$user,$pass) or die("MySQLへの接続に失敗しました。");
  return $link;
}
?>