<?php

function settingMail() {

  $params = array(
    "host" => "mail.yk.rim.or.jp",   // SMTPサーバー名
    "port" => 587,              // ポート番号
    "auth" => true,            // SMTP認証を使用する
    "username" => "gotoh",  // SMTPのユーザー名
    "password" => "monobid9"   // SMTPのパスワード
  );

  return $params;

}

?>